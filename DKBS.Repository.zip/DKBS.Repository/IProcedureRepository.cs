﻿using System.Collections.Generic;
using DKBS.Data;
using DKBS.Domain;

namespace DKBS.Repository
{
    public interface IProcedureRepository
    {
        DKBSDbContext DkbsContext { get; }

        IList<Procedure> GetAllProcedures();

        IList<Procedure> GetProcedureById(int procedureId);
    }
}