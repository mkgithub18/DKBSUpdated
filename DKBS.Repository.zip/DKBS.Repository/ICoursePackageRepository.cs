﻿using System.Collections.Generic;
using DKBS.Domain.CoursePackage;

namespace DKBS.Repository
{
    public interface ICoursePackageRepository
    {
        IList<CoursePackage> GetAllCoursePacakges();
    }
}