﻿using AutoMapper;
using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using DKBS.DTO;
using DKBS.DTO.CoursePackage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DKBS.Repository
{
    public class ChoiceProfile : Profile
    {
        public ChoiceProfile()
        {

            CreateMap<Booking, BookingViewModel>();
            CreateMap<TableSet, TableSetViewModel>();
            CreateMap<BookingRoom, BookingRoomViewModel>();
            CreateMap<BookingArrangementType, BookingArrangementTypeViewModel>();
            CreateMap<BookingAlternativeService, BookingAlternativeServiceViewModel>();
            CreateMap<BookingArrangementType, BookingArrangementTypeViewModel>();
            CreateMap<BookingAlternativeService, BookingAlternativeServiceDTO>();
            CreateMap<BookingAndStatus, BookingAndStatusDTO>();
            CreateMap<BookingArrangementType, BookingArrangementTypeDTO>();
            //CreateMap<Booking, BookingDTO>();
            CreateMap<BookingReference, BookingReferenceDTO>();
            //CreateMap<BookingRegion, BookingRegionDTO>();
            CreateMap<BookingRoom, BookingRoomDTO>();
            CreateMap<Campaign, CampaignDTO>();
            CreateMap<CancellationReason, CancellationReasonDTO>();
            CreateMap<CauseOfRemoval, CauseOfRemovalDTO>();
            CreateMap<CenterMatching, CenterMatchingDTO>();
            CreateMap<CenterType, CenterTypeDTO>();
            CreateMap<ContactPerson, ContactPersonDTO>();
            CreateMap<CoursePackageType, CoursePackageTypeDTO>();
            CreateMap<CrmStatus, CrmStatusDTO>();
            CreateMap<Customer, CustomerDTO>();
            CreateMap<Flow, FlowDTO>();
            CreateMap<IndustryCode, IndustryCodeDTO>();
            CreateMap<ITProcedureStatus, ITProcedureStatusDTO>();
            CreateMap<Land, LandDTO>();
            CreateMap<LeadOfOrigin, LeadOfOriginDTO>();
            CreateMap<MailGroup, MailGroupDTO>();
            CreateMap<MailLanguage, MailLanguageDTO>();
            CreateMap<ParticipantType, ParticipantTypeDTO>();

            CreateMap<PartnerCenterDescriptionDTO, PartnerCenterDescriptionDTO>();
            CreateMap<CRMPartner, CRMPartnerDTO>();
            CreateMap<CRMPartnerDTO, CRMPartner>();
            CreateMap<PartnerEmployee, PartnerEmployeeDTO>();
            CreateMap<PartnerEmployeeDTO, PartnerEmployee>();
            CreateMap<PartnerType, PartnerTypeDTO>();
            CreateMap<Procedure, ProcedureDTO>();
            CreateMap<ProcedureInfo, ProcedureInfoDTO>();
            CreateMap<ProcedureReviewType, ProcedureReviewTypeDTO>();
            CreateMap<Provision, ProvisionDTO>();
            CreateMap<Purpose, PurposeDTO>();
            CreateMap<Region, RegionDTO>();
            CreateMap<ServiceCatalog, ServiceCatalogDTO>();
            CreateMap<ServiceRequestCommunication, ServiceRequestCommunicationDTO>();
            CreateMap<ServiceRequestNote, ServiceRequestNoteDTO>();
            CreateMap<SRConversationItem, SRConversationItemDTO>();
            CreateMap<TableSet, TableSetDTO>();
            CreateMap<TableType, TableTypeDTO>();
            CreateMap<TownZipCode, TownZipCodeDTO>();
            CreateMap<Refreshment, RefreshmentDTO>();
            CreateMap<PartnerCenterInfo, PartnerCenterInfoDTO>();
            CreateMap<PartnerCenterRoomInfo, PartnerCenterRoomInfoDTO>();

            CreateMap<InternalHistory, InternalHistoryDTO>();


            #region Booking

            CreateMap<ProcedureStatus, ProcedureStatusDTO>();
            CreateMap<ProcedureReviewType, ProcedureReviewTypeDTO>();
            CreateMap<ProcedureCancelReason, ProcedureCancelReasonDTO>();
            CreateMap<ProcedureReply, ProcedureReplyDTO>();

            CreateMap<BookingRegion, BookingRegionDTO>()
            .ForMember(dest => dest.RegionDTO, opt => opt.MapFrom(src => src.Region))
            ;

            CreateMap<Booking, BookingDTO>()
            .ForMember(dest => dest.BookingAlternativeServiceDTOs,opt => opt.MapFrom(src => src.BookingAlternativeService))
            .ForMember(dest => dest.BookingAndStatusDTO, opt => opt.MapFrom(src => src.BookingAndStatus))
            .ForMember(dest => dest.BookingArrangementTypeDTOs, opt => opt.MapFrom(src => src.BookingArrangementType))
            .ForMember(dest => dest.BookingRoomDTOs, opt => opt.MapFrom(src => src.BookingRoom))
            .ForMember(dest => dest.CampaignDTO, opt => opt.MapFrom(src => src.Campaign))
            .ForMember(dest => dest.CancellationReasonDTO, opt => opt.MapFrom(src => src.CancellationReason))
            .ForMember(dest => dest.CauseOfRemovalDTO, opt => opt.MapFrom(src => src.CauseOfRemoval))
            .ForMember(dest => dest.ContactPersonDTO, opt => opt.MapFrom(src => src.ContactPerson))
            .ForMember(dest => dest.CRMPartnerDTO, opt => opt.MapFrom(src => src.CRMPartner))
            .ForMember(dest => dest.CustomerDTO, opt => opt.MapFrom(src => src.Customer))
            .ForMember(dest => dest.FlowDTO, opt => opt.MapFrom(src => src.Flow))
            .ForMember(dest => dest.LeadOfOriginDTO, opt => opt.MapFrom(src => src.LeadOfOrigin))
            .ForMember(dest => dest.MailLanguageDTO, opt => opt.MapFrom(src => src.MailLanguage))
            .ForMember(dest => dest.ParticipantTypeDTO, opt => opt.MapFrom(src => src.ParticipantType))
            .ForMember(dest => dest.ProcedureDTOs, opt => opt.MapFrom(src => src.Procedures))
            .ForMember(dest => dest.PurposeDTO, opt => opt.MapFrom(src => src.Purpose))
            .ForMember(dest => dest.BookingRegionDTOs, opt => opt.MapFrom(src => src.BookingRegions))
            .ForMember(dest => dest.TableTypeDTO, opt => opt.MapFrom(src => src.TableType));


            #endregion

            #region CoursePackage

            CreateMap<CoursePackage, CoursePackageDTO>().ForMember(dest=>dest.PackageIncludedItemDTOs,
                opt=>opt.MapFrom(src=>src.PackageIncludedItems));


            CreateMap<PartnerCoursePackage, PartnerCoursePackageDTO>()
           .ForMember(dest => dest.CoursePackageDTO, opt => opt.MapFrom(src => src.CoursePackage))
           .ForMember(dest => dest.CRMPartnerDTO, opt => opt.MapFrom(src => src.CRMPartner))          
           .ForMember(dest => dest.PartnerPackageAdditionalItemDTOs, opt => opt.MapFrom(src => src.PartnerPackageAdditionalItems))
           .ForMember(dest => dest.PartnerPackageIncludedItemDTOs, opt => opt.MapFrom(src => src.PartnerPackageIncludedItems))
           .ForMember(dest => dest.PartnerPackageYearDTOs, opt => opt.MapFrom(src => src.PartnerPackageYears))
           ;
            #endregion

        }
    }
}
