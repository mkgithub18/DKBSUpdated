﻿using DKBS.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DKBSDbContext _context;
        public ICoursePackageRepository CoursePackageRepository { get; }
        public IPartnerCoursePackageRepository PartnerCoursePackageRepository { get; }
        public IBookingRepository BookingRepository { get; }        
        public IProcedureRepository ProcedureRepository { get; }

        public UnitOfWork(DKBSDbContext context)
        {
            _context = context;
            CoursePackageRepository = new CoursePackageRepository(_context);
            PartnerCoursePackageRepository = new PartnerCoursePackageRepository(_context);
            BookingRepository = new BookingRepository(_context);
            ProcedureRepository = new ProcedureRepository(_context);
        }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
