﻿using DKBS.Data;
using DKBS.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public class BookingRepository : GenericRepository<Booking>, IBookingRepository
    {
        public BookingRepository(DbContext context) : base(context)
        {

        }

        public List<Booking> GetAllBookings()
        {
            var res = DkbsContext.Booking
            .Include(x => x.CRMPartner)
            .Include(x => x.Customer)
            .Include(x => x.ContactPerson)
            .Include(x => x.PartnerEmployee)
            .Include(x => x.BookingAndStatus)
            .Include(x => x.Flow)
            .Include(x => x.MailLanguage)
            .Include(x => x.PartnerType)
            .Include(x => x.Campaign)
            .Include(x => x.LeadOfOrigin)
            .Include(x => x.ParticipantType)
            .Include(x => x.Purpose)
            .Include(x => x.TableType)
            .Include(x => x.CauseOfRemoval)
            .Include(x => x.CancellationReason)
            .Include(x => x.BookingRegions).ThenInclude(c => c.Region)
            .Include(x => x.CenterMatching)
            //.Include(x => x.Refreshment) TODO : Is it required? currently commented out
            .Include(x => x.BookingRoom)
            .Include(x => x.BookingArrangementType) //TODO: table settings
            .Include(x => x.BookingAlternativeService)
            .Include(x => x.Procedures)
            .ThenInclude(c => c.ProcedureStatus)
            .Include(x => x.Procedures)
            .ThenInclude(c => c.ProcedureReviewType)  // This is the limitation please check alterative
            .Include(x => x.Procedures)
            .ThenInclude(c => c.ProcedureCancelReason)
            .Include(x => x.Procedures)
            .ThenInclude(c => c.ProcedureReply)
            .ToList();


            return res;
        }

        public Booking GetABookingByBookingId(int bookingId)
        {
            var res = DkbsContext.Booking
                 .Include(x => x.CRMPartner)
                 .Include(x => x.Customer)
                 .Include(x => x.ContactPerson)
                 .Include(x => x.PartnerEmployee)
                 .Include(x => x.BookingAndStatus)
                 .Include(x => x.Flow)
                 .Include(x => x.MailLanguage)
                 .Include(x => x.PartnerType)
                 .Include(x => x.Campaign)
                 .Include(x => x.LeadOfOrigin)
                 .Include(x => x.ParticipantType)
                 .Include(x => x.Purpose)
                 .Include(x => x.TableType)
                 .Include(x => x.CauseOfRemoval)
                 .Include(x => x.CancellationReason)
                 .Include(x => x.BookingRegions).ThenInclude(c => c.Region)
                 .Include(x => x.CenterMatching)
                 //.Include(x => x.Refreshment) TODO : Is it required? currently commented out
                 .Include(x => x.BookingRoom)
                 .Include(x => x.BookingArrangementType) //TODO: table settings
                 .Include(x => x.BookingAlternativeService)
                 .Include(x => x.Procedures)
                 .ThenInclude(c => c.ProcedureStatus)
                 .Include(x => x.Procedures)
                 .ThenInclude(c => c.ProcedureReviewType)  // This is the limitation please check alterative
                 .Include(x => x.Procedures)
                 .ThenInclude(c => c.ProcedureCancelReason)
                 .Include(x => x.Procedures)
                 .ThenInclude(c => c.ProcedureReply)
                 .Where(x=>x.BookingId == bookingId).FirstOrDefault();


            return res;

        }

        public DKBSDbContext DkbsContext
        {
            get
            {
                return _context as DKBSDbContext;
            }
        }
    }
}
