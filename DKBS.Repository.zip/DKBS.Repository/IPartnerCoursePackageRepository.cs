﻿using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public interface IPartnerCoursePackageRepository
    {
        IList<PartnerCoursePackage> GetAllPartnerCoursePacakges(int crmPartnerId);
    }
}
