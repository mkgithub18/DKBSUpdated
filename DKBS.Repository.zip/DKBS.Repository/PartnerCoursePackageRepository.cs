﻿using DKBS.Data;
using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public class PartnerCoursePackageRepository : GenericRepository<PartnerCoursePackage>, IPartnerCoursePackageRepository
    {
        public PartnerCoursePackageRepository(DbContext context) : base(context)
        {

        }

        public IList<PartnerCoursePackage> GetAllPartnerCoursePacakges(int crmPartnerId)
        {

            var res = DkbsContext.PartnerCoursePackage
                     .Include(x => x.CRMPartner)
                     .Include(x => x.CoursePackage.PackageIncludedItems)
                     .Include(x => x.PartnerPackageIncludedItems)
                     .Include(x => x.PartnerPackageAdditionalItems)
                     .Include(x => x.PartnerPackageYears)
                     .Where(x=>x.CrmPartnerId == crmPartnerId)
                     .ToList();

            return res;
        }

        public DKBSDbContext DkbsContext
        {
            get
            {
                return _context as DKBSDbContext;
            }
        }

    }
}
