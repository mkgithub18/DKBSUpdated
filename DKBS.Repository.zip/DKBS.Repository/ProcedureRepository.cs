﻿using DKBS.Data;
using DKBS.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public class ProcedureRepository : GenericRepository<Procedure>, IProcedureRepository
    {

        public ProcedureRepository(DbContext context) : base(context)
        {

        }

        public IList<Procedure> GetAllProcedures()
        {
            var d = DkbsContext.Procedure
                   .Include(x => x.ProcedureReply)
                   .Include(x => x.ProcedureReviewType)
                   .Include(x => x.ProcedureStatus)
                   .Include(x => x.ProcedureCancelReason)
                   .ToList();

            return d;

        }

        public IList<Procedure> GetProcedureById(int procedureId)
        {
            var d = DkbsContext.Procedure
                   .Include(x => x.ProcedureReply)
                   .Include(x => x.ProcedureReviewType)
                   .Include(x => x.ProcedureStatus)
                   .Include(x => x.ProcedureCancelReason)
                   .Where(x=>x.ProcedureId == procedureId)
                   .ToList();

            return null;
        }

        public DKBSDbContext DkbsContext
        {
            get
            {
                return _context as DKBSDbContext;
            }
        }

    }
}
