﻿using DKBS.Data;
using DKBS.Domain.CoursePackage;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public class CoursePackageRepository : GenericRepository<CoursePackage>, ICoursePackageRepository
    {
        public CoursePackageRepository(DbContext context) : base(context)
        {

        }

        public IList<CoursePackage> GetAllCoursePacakges()
        {            
            var d = DkbsContext.CoursePackage.Include(x => x.PackageIncludedItems).ToList();
            return d;
        }

        public DKBSDbContext DkbsContext
        {
            get
            {
                return _context as DKBSDbContext;
            }
        }

    }
}
