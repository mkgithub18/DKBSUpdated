﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        ICoursePackageRepository CoursePackageRepository { get; }

        IPartnerCoursePackageRepository PartnerCoursePackageRepository { get; }

        IBookingRepository BookingRepository { get; }

        IProcedureRepository ProcedureRepository { get; }
        int Complete();

    }
}
