﻿using System.Collections.Generic;
using DKBS.Data;
using DKBS.Domain;

namespace DKBS.Repository
{
    public interface IBookingRepository
    {
        DKBSDbContext DkbsContext { get; }
        Booking GetABookingByBookingId(int bookingId);
        List<Booking> GetAllBookings();
    }
}