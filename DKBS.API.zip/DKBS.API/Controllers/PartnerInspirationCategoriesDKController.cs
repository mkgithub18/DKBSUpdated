﻿using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{
    //public class PartnerInspirationCategoriesDKController
    //{
    //}


    /// <summary>
    /// PartnerInspirationCategoriesController
    /// </summary>
    /// 


    [Route("api/[controller]")]
    [ApiController]
    public class PartnerInspirationCategoriesDKController : ControllerBase
    {
        private IChoiceRepository _choiceRepoistory;

        /// <summary>
        /// PartnerInspirationCategoriesDK
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public PartnerInspirationCategoriesDKController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All GetPartnerInspirationCategoriesDK
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<PartnerInspirationCategoriesDK> GetPartnerInspirationCategoriesDK()
        {
            return Ok(_choiceRepoistory.GetPartnerInspirationCategoriesDK());
        }


        /// <summary>
        /// Get partner details by account id
        /// </summary>
        /// <param name="PartnerInspirationCategoriesDK_Id"></param>
        /// <returns></returns>
        [HttpGet("{PartnerInspirationCategoriesDK_Id}", Name = "getbypartnerinspirationcategoriesDK")]
        public ActionResult<PartnerInspirationCategoriesDKDTO> getbypartnerinspirationcategoriesDK(int PartnerInspirationCategoriesDK_Id)
        {
            //return _choiceRepoistory.GetPartnerInspirationCategoriesDK().FirstOrDefault(c => c.PartnerInspirationCategoriesDKId == PartnerInspirationCategoriesDK_Id);


            var ObjPartnerInspirationCategoriesDK = _choiceRepoistory.GetPartnerInspirationCategoriesDK().FirstOrDefault(c => c.PartnerInspirationCategoriesDKId == PartnerInspirationCategoriesDK_Id);


            if (ObjPartnerInspirationCategoriesDK == null)
            {
                return NotFound(PartnerInspirationCategoriesDK_Id);
            }

            // var returnval = _mapper.Map<PartnerCenterDescription, PartnerCenterDescriptionDTO>(ObjPartnerCenterDescriptions);

            return Ok(ObjPartnerInspirationCategoriesDK);

        }

        /// <summary>
        /// Get PartnerInspirationCategoriesDK_Id by PartnerId
        /// </summary>
        /// <param name="PartnerId"></param>
        /// <returns></returns>
        [Route("getbypartnerId")]
        [HttpGet()]
        public ActionResult<PartnerInspirationCategoriesDKDTO> GetById(int PartnerId)
        {
            return _choiceRepoistory.GetPartnerInspirationCategoriesDK().FirstOrDefault(c => c.CRMPartnerId == PartnerId);
        }


        /// <summary>y
        /// Update UpdatePartnerCenterInfo
        /// </summary>
        /// <param name="PartnerInspirationCategoriesDK_Id"></param>
        /// <param name="PartnerInspirationCategoriesDKDTO"></param>
        /// <returns></returns>

        [HttpPut("{PartnerInspirationCategoriesDK_Ids}")]
        public IActionResult UpdatePartnerInspirationCategoriesDK(int PartnerInspirationCategoriesDK_Id, [FromBody] PartnerInspirationCategoriesDKDTO PartnerInspirationCategoriesDKDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (PartnerInspirationCategoriesDKDTO == null)
            {
                return BadRequest();
            }

            var partnerInspirationCategoriesDK = _choiceRepoistory.GetPartnerInspirationCategoriesDK().Find(c => c.PartnerInspirationCategoriesDKId == PartnerInspirationCategoriesDK_Id);

            if (partnerInspirationCategoriesDK == null)
            {
                return BadRequest();
            }

            partnerInspirationCategoriesDK = PartnerInspirationCategoriesDKDTO;

            _choiceRepoistory.Complete();
            return NoContent();
        }


        /// <summary>
        /// Creating PartnerCenterDescription
        /// </summary>
        /// <param name="partnerInspirationCategoriesDKDTO"></param>
        /// <response code="201">Returns the newly created PartnerInspirationCategoriesDK</response>
        /// <response code="400">If the item is null</response>            
        /// <returns>newly created PartnerCenterDescription</returns>
        ///
        [HttpPost("")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public ActionResult<IEnumerable<PartnerInspirationCategoriesDKDTO>> PartnerInspirationCategoriesDK([FromBody] PartnerInspirationCategoriesDKDTO partnerInspirationCategoriesDKDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (partnerInspirationCategoriesDKDTO == null)
            {
                return BadRequest();
            }

            var checkPartnerInspirationCategoriesDK_Id = _choiceRepoistory.GetPartnerInspirationCategoriesDK().Find(c => c.PartnerInspirationCategoriesDKId == partnerInspirationCategoriesDKDTO.PartnerInspirationCategoriesDKId);

            if (checkPartnerInspirationCategoriesDK_Id != null)
            {
                return BadRequest();
            }

            PartnerInspirationCategoriesDK newlypartnerInspirationCategoriesDKDTO = new PartnerInspirationCategoriesDK()
            {
                PartnerInspirationCategoriesDKId = partnerInspirationCategoriesDKDTO.PartnerInspirationCategoriesDKId,
                CRMPartnerId = partnerInspirationCategoriesDKDTO.CRMPartnerId,
                // Room_Name = partnerInspirationCategoriesDTO.Room_Name,
                Heading = partnerInspirationCategoriesDKDTO.Heading,
                Description = partnerInspirationCategoriesDKDTO.Description,
                Price = partnerInspirationCategoriesDKDTO.Price,
                ApprovalStatus = partnerInspirationCategoriesDKDTO.ApprovalStatus,
                Sorting = partnerInspirationCategoriesDKDTO.Sorting,
                ApprovalStatusId = partnerInspirationCategoriesDKDTO.ApprovalStatusId,
                CreatedDate = partnerInspirationCategoriesDKDTO.CreatedDate,
                CreatedBy = partnerInspirationCategoriesDKDTO.CreatedBy,
                LastModified = partnerInspirationCategoriesDKDTO.LastModified,
                LastModifiedBY = partnerInspirationCategoriesDKDTO.LastModifiedBY
            };

            _choiceRepoistory.SetpartnerInspirationCategoriesDK(newlypartnerInspirationCategoriesDKDTO);
            _choiceRepoistory.Complete();
            return CreatedAtRoute("GetPartnerByAccountId2", new { newlypartnerInspirationCategoriesDKDTO.PartnerInspirationCategoriesDKId }, partnerInspirationCategoriesDKDTO);

        }

    }
}