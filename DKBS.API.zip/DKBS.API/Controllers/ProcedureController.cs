﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.DTO;
using DKBS.DTO.Procedure;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// Procedure
    /// </summary>   
    [Route("api/[controller]")]
    [ApiController]
    public class ProcedureController : Controller
    {

        private IChoiceRepository _choiceRepoistory;
        private IMapper _mapper;

        /// <summary>
        /// Procedure
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public ProcedureController(IChoiceRepository choiceRepoistory,IMapper mapper)
        {
            _choiceRepoistory = choiceRepoistory;
            _mapper = mapper;
        }

        /// <summary>
        /// Get All Procedures
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<ProcedureDTO> GetProcedures()
        {
            var res = _choiceRepoistory.GetProcedures();
            var temp = _mapper.Map<List<ProcedureDTO>>(res);

            return Ok(_choiceRepoistory.GetProcedures());
        }

        /// <summary>
        /// Get procedure by id
        /// </summary>
        /// <param name="procedureId"></param>
        /// <returns></returns>
        [HttpGet("{procedureId}")]
        public ActionResult<ProcedureDTO> GetProcedureById(int procedureId)
        {
            var res = _choiceRepoistory.GetProcedures();
            var temp = _mapper.Map<List<ProcedureDTO>>(res);
            // return _choiceRepoistory.GetProcedures().FirstOrDefault(c => c.ProcedureId == procedureId);
            return null;
        }


        /// <summary>
        /// Update procedure
        /// </summary>
        /// <param name="procedureId"></param>
        /// <param name="putProcedureDTO"></param>
        /// <returns></returns>
        [HttpPut("{procedureId}")]
        public IActionResult UpdateProcedure(int procedureId, [FromBody] PutProcedureDTO putProcedureDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (putProcedureDTO == null)
                return BadRequest(); // TODO Error mesg

            var procedure = _choiceRepoistory.GetProcedures().Find(c => c.ProcedureId == procedureId);

            if (procedure == null)
            {
                return BadRequest();
            }

            procedure.ProcedureTitle = putProcedureDTO.ProcedureTitle;
            procedure.CauseOfRemovalId = putProcedureDTO.CauseOfRemovalId;
            procedure.ProcedureReviewTypeId = putProcedureDTO.ProcedureReviewTypeId;
            procedure.PartnerEmployeeId = putProcedureDTO.PartnerEmployeeId;
            procedure.CustomerId = putProcedureDTO.CustomerId;
            procedure.SRCommunicationId = putProcedureDTO.SRCommunicationId;
            procedure.ContactId = putProcedureDTO.ContactId;
            procedure.ProcedureCancelReasonId = putProcedureDTO.ProcedureCancelReasonId;
            procedure.ProcedureReplyId = putProcedureDTO.ProcedureReplyId;
            procedure.UsedInEmailOffer = putProcedureDTO.UsedInEmailOffer;
            procedure.TurnOffNotification = putProcedureDTO.TurnOffNotification;
            procedure.ProcedureSharePointId = putProcedureDTO.ProcedureSharePointId;
            procedure.IndustryCode = putProcedureDTO.IndustryCode;
            procedure.ProcedureStatusId = putProcedureDTO.ProcedureStatusId;
            procedure.TotalPrice = putProcedureDTO.TotalPrice;
            procedure.SystemPrice = putProcedureDTO.SystemPrice;

            //TODO : Below item are server based
            procedure.LastModified = putProcedureDTO.LastModified;
            procedure.LastModifiedBy = putProcedureDTO.LastModifiedBy;
            procedure.CreatedDate = putProcedureDTO.CreatedDate;
            procedure.CreatedBy = putProcedureDTO.CreatedBy;

            _choiceRepoistory.Complete();
            return NoContent();
        }
    }
}