﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using DKBS.DTO;
using DKBS.Infrastructure.IntegrationServices;
using DKBS.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// Partner controller
    /// </summary>
    /// 
   // [Authorize]
    [Route("partner")]
    [ApiController]
    public class PartnerController : ControllerBase
    {
        private readonly IChoiceRepository _choiceRepoistory;
        private readonly IConfiguration _configuration;
        private readonly ISharepointService _sharePointService;
        private IMapper _mapper;
        /// <summary>
        /// Partner controller
        /// </summary>
        public PartnerController(IChoiceRepository choiceReposiroty, IMapper mapper, ISharepointService sharePointService, IConfiguration configuration)
        {
            _choiceRepoistory = choiceReposiroty;
            _mapper = mapper;
            _sharePointService = sharePointService;
            _configuration = configuration;
        }

        /// <summary>
        /// Get All partner details.
        /// </summary>
        /// <returns>List of partners.</returns>
        [HttpGet()]
        public ActionResult<CRMPartner> GetPartners()
        {
            return Ok(_choiceRepoistory.GetPartners());
        }
        /// <summary>
        /// Get Partner by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id:int}")]
        public ActionResult<CRMPartnerDTO> GetPartnerById(int id)
        {
            return _choiceRepoistory.GetPartners().Find(c => c.CRMPartnerId == id);
        }


        /// <summary>
        /// Creating Partner
        /// </summary>
        /// <param name="dto"></param>
        /// <response code="201">Returns the newly created partner</response>
        /// <response code="400">If the item is null</response>            
        /// <returns>newly created partner</returns>
        ///
        
        [HttpPost("")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> CreatePartner([FromBody] CRMPartnerDTO dto)
        {

            try
            {
                if (string.IsNullOrEmpty(dto.AccountId))
                {
                    ModelState.AddModelError("AccountId", "AccountId can't be null");
                    return BadRequest(ModelState);
                }

                if (dto == null)
                {
                    ModelState.AddModelError("Partner", "Partner object can't be null");
                    return BadRequest(ModelState);
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var partner = _choiceRepoistory.GetById<CRMPartner>(c => c.AccountId == dto.AccountId);

                if (partner != null)
                {
                    ModelState.AddModelError("Partner", $"Partner entry already exist for AccountId {dto.AccountId}.");
                    return BadRequest(ModelState);
                }

                // if partner type is "partner then assign membershiptype.
                if(!string.IsNullOrWhiteSpace(dto.Partnertype) && dto.Partnertype.ToLower() == "partner")
                {
                    dto.Partnertype = dto.MembershipType;
                }

                CRMPartner newPartner = _mapper.Map<CRMPartnerDTO, CRMPartner>(dto);
                newPartner.CreatedBy = "CRM";
                newPartner.CreatedDate = DateTime.UtcNow;
                newPartner.LastModified = DateTime.UtcNow;
                newPartner.LastModifiedBy = "CRM";

                if (bool.Parse(_configuration["SharePointIntegrationEnabled"].ToString()))
                {
                    var sharePointId = await _sharePointService.InsertPartnerAsync(newPartner);
                    if (sharePointId <= 0)
                    {
                        return StatusCode(500, "An error occurred while creating sharepoint partner. Please try again or contact adminstrator");
                    }
                    newPartner.SharePointId = sharePointId;
                }

                _choiceRepoistory.Attach<CRMPartner>(newPartner);
                _choiceRepoistory.Complete();

                #region All related fileds

                //===========Create Partner Center Description=================================

                List<PartnerCenterDescription> partnerCenterDescriptions = new List<PartnerCenterDescription>(3);
                partnerCenterDescriptions.Add(new PartnerCenterDescription() { Langauge = "UK", CRMPartnerId = newPartner.CRMPartnerId });
                partnerCenterDescriptions.Add(new PartnerCenterDescription() { Langauge = "DK", CRMPartnerId = newPartner.CRMPartnerId });
                partnerCenterDescriptions.Add(new PartnerCenterDescription() { Langauge = "Ger", CRMPartnerId = newPartner.CRMPartnerId });

                foreach (var item in partnerCenterDescriptions)
                {
                    _choiceRepoistory.Attach<PartnerCenterDescription>(item);
                }


                //===========Create Partner Course Package=================================

                foreach (var item in _choiceRepoistory.GetAll<CoursePackage>())
                {
                    PartnerCoursePackage partnerCoursePackage = new PartnerCoursePackage();
                    partnerCoursePackage.CoursePackageId = item.CoursePackageId;
                    //partnerCoursePackage.Name = item.CoursePackageEng; TODO: Is Name required here?
                    partnerCoursePackage.CrmPartnerId = newPartner.CRMPartnerId;
                    _choiceRepoistory.Attach<PartnerCoursePackage>(partnerCoursePackage);

                    PartnerPackageIncludedItem partnerPackageIncludedItem = new PartnerPackageIncludedItem();
                    partnerPackageIncludedItem.PartnerCoursePackageId = partnerCoursePackage.PartnerCoursePackageId;

                    PartnerPackageAdditionalItem partnerPackageAdditionalItem = new PartnerPackageAdditionalItem();
                    partnerPackageAdditionalItem.PartnerCoursePackageId = partnerCoursePackage.PartnerCoursePackageId;

                    PartnerPackageYear partnerPackageYear = new PartnerPackageYear();
                    partnerPackageYear.PartnerCoursePackageId = partnerCoursePackage.PartnerCoursePackageId;
                    // DO it for other also partnetinclude
                    // Save these value in DB
                }


                //===========Create PartnerCenterInfo=================================

                PartnerCenterInfo partnerCenterInfo = new PartnerCenterInfo();
                partnerCenterInfo.CrmPartnerId = newPartner.CRMPartnerId;
                _choiceRepoistory.Attach<PartnerCenterInfo>(partnerCenterInfo);



                #endregion

                return CreatedAtRoute("GetPartnerByAccountId", new { newPartner.AccountId }, dto);
            }
            catch (Exception ex)
            {
                // TODO : Add logging and decide on showing ex.message
                return StatusCode(500, "An error occurred while creating partner. Please try again or contact adminstrator");
            }
        }

        /// <summary>
        /// Get partner details by account id
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        [HttpGet("{accountId}", Name = "GetPartnerByAccountId")]
        public ActionResult<CRMPartnerDTO> GetPartnerByAccountId(string accountId)
        {
            var partner = _choiceRepoistory.GetById<CRMPartner>(c => c.AccountId == accountId);

            if (partner == null)
            {
                return NotFound(accountId);
            }

            var returnval = _mapper.Map<CRMPartner, CRMPartnerDTO>(partner);

            return Ok(returnval);
        }

        /// <summary>
        /// Update partner
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// 
        [HttpPut("{accountId}")]
        public async Task<IActionResult> UpdatePartner(string accountId, [FromBody] CRMPartnerDTO dto)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(accountId))
                {
                    ModelState.AddModelError("AccountId", "AccountId can't be null or empty.");
                    return BadRequest(ModelState);
                }

                if (dto == null)
                {
                    ModelState.AddModelError("Partner", "Partner object can't be null");
                    return BadRequest(ModelState);
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var partner = _choiceRepoistory.GetById<CRMPartner>(c => c.AccountId == accountId);

                if (partner == null)
                {
                    ModelState.AddModelError("Partner", $"No Partner found with AccountId {accountId}");
                    return NotFound(ModelState);
                }

                // if partner type is "partner then assign membershiptype.
                if (!string.IsNullOrWhiteSpace(dto.Partnertype) && dto.Partnertype.ToLower() == "partner")
                {
                    dto.Partnertype = dto.MembershipType;
                }

                partner.Partnertype = dto.Partnertype;
                partner.MembershipType = dto.MembershipType;
                partner.PartnerName = dto.PartnerName;
                partner.CVR = dto.CVR;
                partner.Telefon = dto.Telefon;
                partner.Centertype = dto.Centertype;

                partner.Address1 = dto.Address1;
                partner.Address2 = dto.Address2;
                partner.Town = dto.Town;

                partner.PostNumber = dto.PostNumber;
                partner.Land = dto.Land;
                partner.StateAgreement = dto.StateAgreement;
                partner.Debitornummer = dto.Debitornummer;
                partner.Debitornummer2 = dto.Debitornummer2;
                partner.Regions = dto.Regions;
                partner.MembershipStartDate = dto.MembershipStartDate;
                partner.PublicURL = dto.PublicURL;
                partner.Email = dto.Email;
                partner.Website = dto.Website;
                partner.PanoramView = dto.PanoramView;
                partner.RecommandedNPGRT60 = dto.RecommandedNPGRT60;
                partner.QualityAssuredNPSGRD30 = dto.QualityAssuredNPSGRD30;
                partner.LastModified = DateTime.UtcNow;
                partner.LastModifiedBy = "CRM";  //later need to change
                _choiceRepoistory.Attach(partner);
                if (bool.Parse(_configuration["SharePointIntegrationEnabled"].ToString()))
                {
                    var status = await _sharePointService.UpdatePartnerAsync(partner);
                    if (!status)
                    {
                        return StatusCode(500, "An error occurred while creating sharepoint partner. Please try again or contact adminstrator");
                    }
                }
                _choiceRepoistory.Complete();

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while updating Partner. Please try again or contact adminstrator");
            }
        }


    }
}
