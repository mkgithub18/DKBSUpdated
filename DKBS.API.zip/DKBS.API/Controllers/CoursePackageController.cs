﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain.CoursePackage;
using DKBS.DTO.CoursePackage;
using DKBS.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CoursePackageController : ControllerBase
    {
        private IChoiceRepository _choiceRepository;
        private IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="choiceRepository"></param>
        /// <param name="mapper"></param>
        public CoursePackageController(IChoiceRepository choiceRepository, IMapper mapper)
        {
            _choiceRepository = choiceRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<CoursePackageDTO> GetAllCoursePackages()
        {
            var res = _choiceRepository.GetAllPartnerCoursePackagesById(1);
            var t = _mapper.Map<List<PartnerCoursePackageDTO>>(res.ToList());

            return Ok(t);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="coursePackageId"></param>
        /// <param name="putCoursePackageDTO"></param>
        /// <returns></returns>
        [HttpPut("{coursePackageId}")]
        public ActionResult<PartnerCoursePackageDTO> UpdateCoursePackages(int coursePackageId, [FromBody] PutCoursePackageDTO putCoursePackageDTO)
        {
            var coursePackageEntryInDb = _choiceRepository.GetById<CoursePackage>(x => x.CoursePackageId == coursePackageId);

            coursePackageEntryInDb.CoursePackageName = putCoursePackageDTO.CoursePackageName;
            coursePackageEntryInDb.CoursePackageNameEN = putCoursePackageDTO.CoursePackageNameEN;
            coursePackageEntryInDb.CreatedBy = putCoursePackageDTO.CreatedBy;
            coursePackageEntryInDb.CreatedDate = putCoursePackageDTO.CreatedDate;
            coursePackageEntryInDb.Offered = putCoursePackageDTO.Offered;
            coursePackageEntryInDb.LastModified = putCoursePackageDTO.LastModified;
            coursePackageEntryInDb.LastModifiedBy = putCoursePackageDTO.LastModifiedBy;
            coursePackageEntryInDb.Price = putCoursePackageDTO.Price;

            var allPackageIncludedItems = _choiceRepository.GetAll<PackageIncludedItem>(x => x.CoursePackageId == coursePackageEntryInDb.CoursePackageId);

            // First remove all 
            foreach (var packageIncludeItem in allPackageIncludedItems)
            {
                _choiceRepository.Remove<PackageIncludedItem>(packageIncludeItem);
            }



            foreach (var packageIncludedItemDTO in putCoursePackageDTO.PackageIncludedItemDTOs)
            {
                PackageIncludedItem packageIncludedItem = new PackageIncludedItem();
                packageIncludedItem.CoursePackageId = packageIncludedItemDTO.CoursePackageId;
                packageIncludedItem.CreatedBy = packageIncludedItemDTO.CreatedBy;
                packageIncludedItem.CreatedDate = packageIncludedItemDTO.CreatedDate;
                packageIncludedItem.DK = packageIncludedItemDTO.DK;
                packageIncludedItem.Included = packageIncludedItemDTO.Included;
                packageIncludedItem.LastModified = packageIncludedItemDTO.LastModified;
                packageIncludedItem.LastModifiedBy = packageIncludedItemDTO.LastModifiedBy;
                packageIncludedItem.SortingOrder = packageIncludedItemDTO.SortingOrder;
                packageIncludedItem.UK = packageIncludedItemDTO.UK;
                _choiceRepository.Add<PackageIncludedItem>(packageIncludedItem);
            }

            _choiceRepository.Complete();

            return null;
        }

    }
}