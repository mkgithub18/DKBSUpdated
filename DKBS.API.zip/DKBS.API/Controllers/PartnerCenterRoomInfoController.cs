﻿using AutoMapper;
using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// PartnerCenterRoomInfoController
    /// </summary>
    /// 


    [Route("api/[controller]")]
    [ApiController]
    public class PartnerCenterRoomInfoController : Controller
    {
        private IChoiceRepository _choiceRepoistory;
        private IMapper _mapper;

        /// <summary>
        /// PartnerCenterRoomInfo
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public PartnerCenterRoomInfoController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All GetPartnerCenterRoomInfo
        /// </summary>
        /// <returns></returns>
        //[HttpGet()]
        [HttpGet("[action]/{name}", Name = "GetPartnerCenterRoomInfo")]
        public ActionResult<PartnerCenterRoomInfoDTO> GetPartnerCenterRoomInfo()
        {
            return Ok(_choiceRepoistory.GetPartnerCenterRoomInfo());
        }

        ///// <summary>
        ///// Get PartnerCenterRoomInfo_Id by id
        ///// </summary>
        ///// <param name="PartnerCenterRoomInfo_Id"></param>
        ///// <returns></returns>
       
        // [HttpGet("{PartnerCenterRoomInfo_Id}", Name = "GetbyPartnerCenterRoomInfo")]
        //public ActionResult<PartnerCenterRoomInfoDTO> GetbyPartnerCenterRoomInfo(int PartnerCenterRoomInfo_Id)
        //{
        //    return _choiceRepoistory.GetPartnerCenterRoomInfo().FirstOrDefault(c => c.PartnerCenterRoomInfoId == PartnerCenterRoomInfo_Id);
        //}



        /// <summary>
        /// Get partner details by partnerCenterDescriptionId
        /// </summary>
        /// <param name="PartnerCenterRoomInfo_Id"></param>
        /// <returns></returns>
        [HttpGet("{PartnerCenterRoomInfo_Id}", Name = "GetByPartnerCenterRoomInfo")]
        public ActionResult<PartnerCenterRoomInfoDTO> GetByPartnerCenterRoomInfo(int PartnerCenterRoomInfo_Id)
        {
            //return _choiceRepoistory.GetPartnerCenterDescriptions().FirstOrDefault(c => c.PartnerCenterDescriptionId == partnerCenterDescriptionId);

            var ObjPartnerCenterRoomInfo = _choiceRepoistory.GetPartnerCenterRoomInfo().FirstOrDefault(c => c.PartnerCenterRoomInfoId == PartnerCenterRoomInfo_Id);


            if (ObjPartnerCenterRoomInfo == null)
            {
                return NotFound(PartnerCenterRoomInfo_Id);
            }

            // var returnval = _mapper.Map<PartnerCenterDescription, PartnerCenterDescriptionDTO>(ObjPartnerCenterDescriptions);

            return Ok(ObjPartnerCenterRoomInfo);


        }

        /// <summary>
        /// Get PartnerCenterRoomInfoDTO by PartnerId
        /// </summary>
        /// <param name="crmPartnerId"></param>
        /// <returns></returns>
        [Route("GetByPartnerId")]
        [HttpGet()]
        public ActionResult<PartnerCenterRoomInfoDTO> GetById(int crmPartnerId)
        {
            return _choiceRepoistory.GetPartnerCenterRoomInfo().FirstOrDefault(c => c.CRMPartnerId == crmPartnerId);
        }



        /// <summary>
        /// Update UpdatePartnerCenterInfo
        /// </summary>
        /// <param name="PartnerCenterRoomInfo_Id"></param>
        /// <param name="partnerCenterRoomInfoDTO"></param>
        /// <returns></returns>

        [HttpPut("{PartnerCenterInfo_Id}")]
        public IActionResult UpdatepartnerCenterRoomInfo(int PartnerCenterRoomInfo_Id, [FromBody] PartnerCenterRoomInfoDTO partnerCenterRoomInfoDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (partnerCenterRoomInfoDTO == null)
            {
                return BadRequest();
            }

            var partnerCenterRoomInfo = _choiceRepoistory.GetPartnerCenterRoomInfo().Find(c => c.PartnerCenterRoomInfoId == PartnerCenterRoomInfo_Id);

            if (partnerCenterRoomInfo == null)
            {
                return BadRequest();
            }

            partnerCenterRoomInfo = partnerCenterRoomInfoDTO;

            _choiceRepoistory.Complete();
            return NoContent();
        }


        /// <summary>
        /// Creating PartnerCenterDescription
        /// </summary>
        /// <param name="partnerCenterRoomInfoDTO"></param>
        /// <response code="201">Returns the newly created partner</response>
        /// <response code="400">If the item is null</response>            
        /// <returns>newly created PartnerCenterDescription</returns>
        ///

        [HttpPost("")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public ActionResult PartnerCenterRoomInfo([FromBody] PartnerCenterRoomInfoDTO partnerCenterRoomInfoDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (partnerCenterRoomInfoDTO == null)
            {
                return BadRequest();
            }

            var checkPartnerCenterRoomInfoIdinDb = _choiceRepoistory.GetPartnerCenterRoomInfo().Find(c => c.PartnerCenterRoomInfoId == partnerCenterRoomInfoDTO.PartnerCenterRoomInfoId);

            if (checkPartnerCenterRoomInfoIdinDb != null)
            {
                return BadRequest();
            }

            PartnerCenterRoomInfo newlyCreatedPartnerCenterRoomInfo = new PartnerCenterRoomInfo()
            {
                PartnerCenterRoomInfoId = partnerCenterRoomInfoDTO.PartnerCenterRoomInfoId,
                CRMPartnerId = partnerCenterRoomInfoDTO.CRMPartnerId,
                MaxPersonsAtMeetingTable = partnerCenterRoomInfoDTO.MaxPersonsAtMeetingTable,
                MaxPersonsAtSchoolTable = partnerCenterRoomInfoDTO.MaxPersonsAtSchoolTable,
                MaxPersonsAtRowOfChairs = partnerCenterRoomInfoDTO.MaxPersonsAtRowOfChairs,
                MaxPersonsAtIslands = partnerCenterRoomInfoDTO.MaxPersonsAtIslands,
                MaxPersonsAtUTable = partnerCenterRoomInfoDTO.MaxPersonsAtUTable,
                IsRoomdividetosmallroom = partnerCenterRoomInfoDTO.IsRoomdividetosmallroom,
                Remark = partnerCenterRoomInfoDTO.RoomName,
                CreatedDate = partnerCenterRoomInfoDTO.CreatedDate,
                CreatedBy = partnerCenterRoomInfoDTO.CreatedBy,
                LastModified = partnerCenterRoomInfoDTO.LastModified,
                LastModifiedBY = partnerCenterRoomInfoDTO.LastModifiedBY

                //LastModifiedBY = partnerCenterRoomInfoDTO.LastModifiedBY,
                //LastModified = partnerCenterRoomInfoDTO.LastModified
            };
          //  var destination = Mapper.Map<PartnerCenterRoomInfo, PartnerCenterRoomInfoDTO>(newlyCreatedPartnerCenterRoomInfo);


            //_choiceRepoistory.GetPartnerCenterRoomInfo().Add(destination);
            //_choiceRepoistory.Complete();

            _choiceRepoistory.SetpartnerCenterRoomInfo(newlyCreatedPartnerCenterRoomInfo);
            _choiceRepoistory.Complete();
            return CreatedAtRoute("GetByPartnerCenterRoomInfo", new { newlyCreatedPartnerCenterRoomInfo.PartnerCenterRoomInfoId }, partnerCenterRoomInfoDTO);

            
        }


    }

}
