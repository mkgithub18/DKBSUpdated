﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain.CoursePackage;
using DKBS.DTO.CoursePackage;
using DKBS.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DKBS.API.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PartnerCoursePackageController : ControllerBase
    {
        private IChoiceRepository _choiceRepository;
        IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="choiceRepository"></param>
        /// <param name="mapper"></param>
        public PartnerCoursePackageController(IChoiceRepository choiceRepository, IMapper mapper)
        {
            _choiceRepository = choiceRepository;
            _mapper = mapper;
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="crmPartnerId"></param>
        /// <returns></returns>
        [HttpGet("{crmPartnerId}")]
        public ActionResult<PartnerCoursePackageDTO> GetAllPartnerCoursePackages(int crmPartnerId)
        {
            //TODO : Find a shortcut for mapping
            var res = _choiceRepository.GetAllPartnerCoursePackagesById(crmPartnerId);
            var resDto = _mapper.Map<List<PartnerCoursePackageDTO>>(res);

            // Below code is intentionally commented for reference
            //for (int i = 0; i < res.Count; i++)
            //{
            //    for (int j = 0; j < res[i].PartnerPackageIncludedItems.Count; j++)
            //    {
            //        PackageIncludedItem packageIncludedItem = res[j].PartnerPackageIncludedItems[j].PackageIncludedItem;
            //        var d = _mapper.Map<PackageIncludedItem, PackageIncludedItemDTO>(packageIncludedItem);
            //        resDto[i].PartnerPackageIncludedItemDTOs[j].PackageIncludedItemDTO = d;
            //    }
            //}

            return Ok(resDto);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="crmPartnerId"></param>
        /// <param name="putPartnerCoursePackageDTO"></param>
        /// <returns></returns>
        [HttpPut("{crmPartnerId}")]
        public ActionResult<PartnerCoursePackageDTO> UpdatePartnerCoursePackages(int crmPartnerId, [FromBody] PutPartnerCoursePackageDTO putPartnerCoursePackageDTO)
        {

            var partnerCoursePackageEntryInDb = _choiceRepository.GetById<PartnerCoursePackage>(x => x.CrmPartnerId == crmPartnerId);

            partnerCoursePackageEntryInDb.CoursePackageId = putPartnerCoursePackageDTO.CoursePackageId;
            partnerCoursePackageEntryInDb.ContentStatusId = putPartnerCoursePackageDTO.ContentStatusId;
            partnerCoursePackageEntryInDb.CreatedBy = putPartnerCoursePackageDTO.CreatedBy;
            partnerCoursePackageEntryInDb.CreatedDate = putPartnerCoursePackageDTO.CreatedDate;
            partnerCoursePackageEntryInDb.LastModified = putPartnerCoursePackageDTO.LastModified;
            partnerCoursePackageEntryInDb.LastModifiedBy = putPartnerCoursePackageDTO.LastModifiedBy;
            partnerCoursePackageEntryInDb.Offered = putPartnerCoursePackageDTO.Offered;
            partnerCoursePackageEntryInDb.Price = putPartnerCoursePackageDTO.Price;


            //PartnerPackageIncludedItem
            var allPartnerPackageIncludedItemsInDb = _choiceRepository.GetAll<PartnerPackageIncludedItem>(x => x.PartnerCoursePackageId == partnerCoursePackageEntryInDb.PartnerCoursePackageId);
            // First remove all 
            foreach (var partnerPackageIncludedItem in allPartnerPackageIncludedItemsInDb)
            {
                _choiceRepository.Remove<PartnerPackageIncludedItem>(partnerPackageIncludedItem);
            }

            foreach (var packageIncludedItemDTO in putPartnerCoursePackageDTO.PartnerPackageIncludedItemDTOs)
            {
                PartnerPackageIncludedItem partnerPackageIncludedItem = new PartnerPackageIncludedItem();
                partnerPackageIncludedItem.PartnerCoursePackageId = partnerCoursePackageEntryInDb.PartnerCoursePackageId;

                partnerPackageIncludedItem.CreatedBy = packageIncludedItemDTO.CreatedBy;
                partnerPackageIncludedItem.CreatedDate = packageIncludedItemDTO.CreatedDate;
                partnerPackageIncludedItem.LastModified = packageIncludedItemDTO.LastModified;
                partnerPackageIncludedItem.LastModifiedBy = packageIncludedItemDTO.LastModifiedBy;
                partnerPackageIncludedItem.Offered = packageIncludedItemDTO.Offered;
                _choiceRepository.Add<PartnerPackageIncludedItem>(partnerPackageIncludedItem);
            }


            //PartnerPackageAdditionalItem
            var allPartnerPackageAdditionalItemInDb = _choiceRepository.GetAll<PartnerPackageAdditionalItem>(x => x.PartnerCoursePackageId == partnerCoursePackageEntryInDb.PartnerCoursePackageId);
            // First remove all 
            foreach (var partnerPackageAdditionalItem in allPartnerPackageAdditionalItemInDb)
            {
                _choiceRepository.Remove<PartnerPackageAdditionalItem>(partnerPackageAdditionalItem);
            }

            foreach (var partnerPackageAdditionalItemDTO in putPartnerCoursePackageDTO.PartnerPackageAdditionalItemDTOs)
            {
                PartnerPackageAdditionalItem  partnerPackageAdditionalItem = new PartnerPackageAdditionalItem();
                partnerPackageAdditionalItem.PartnerCoursePackageId = partnerCoursePackageEntryInDb.PartnerCoursePackageId;

                partnerPackageAdditionalItem.CreatedBy = partnerPackageAdditionalItemDTO.CreatedBy;
                partnerPackageAdditionalItem.CreatedDate = partnerPackageAdditionalItemDTO.CreatedDate;
                partnerPackageAdditionalItem.LastModified = partnerPackageAdditionalItemDTO.LastModified;
                partnerPackageAdditionalItem.LastModifiedBy = partnerPackageAdditionalItemDTO.LastModifiedBy;
                partnerPackageAdditionalItem.Price = partnerPackageAdditionalItemDTO.Price;
                partnerPackageAdditionalItem.UK = partnerPackageAdditionalItemDTO.UK;
                partnerPackageAdditionalItem.DK = partnerPackageAdditionalItemDTO.DK;

                _choiceRepository.Add<PartnerPackageAdditionalItem>(partnerPackageAdditionalItem);
            }


            //PartnerPackageYear
            var allPartnerPackageYearsInDb = _choiceRepository.GetAll<PartnerPackageYear>(x => x.PartnerCoursePackageId == partnerCoursePackageEntryInDb.PartnerCoursePackageId);
            // First remove all 
            foreach (var partnerPackageYearItem in allPartnerPackageYearsInDb)
            {
                _choiceRepository.Remove<PartnerPackageYear>(partnerPackageYearItem);
            }

            foreach (var partnerPackageAdditionalItemDTO in putPartnerCoursePackageDTO.PartnerPackageYearDTOs)
            {
                PartnerPackageYear partnerPackageYear = new PartnerPackageYear();
                partnerPackageYear.PartnerCoursePackageId = partnerCoursePackageEntryInDb.PartnerCoursePackageId;

                partnerPackageYear.CreatedBy = partnerPackageAdditionalItemDTO.CreatedBy;
                partnerPackageYear.CreatedDate = partnerPackageAdditionalItemDTO.CreatedDate;
                partnerPackageYear.LastModified = partnerPackageAdditionalItemDTO.LastModified;
                partnerPackageYear.LastModifiedBy = partnerPackageAdditionalItemDTO.LastModifiedBy;
                partnerPackageYear.PricePerPerson = partnerPackageAdditionalItemDTO.PricePerPerson;
                partnerPackageYear.Year = partnerPackageAdditionalItemDTO.Year;

                _choiceRepository.Add<PartnerPackageYear>(partnerPackageYear);
            }


            _choiceRepository.Complete();

            return null;
        }



    }
}