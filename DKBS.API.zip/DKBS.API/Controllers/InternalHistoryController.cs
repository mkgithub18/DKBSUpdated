﻿using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// EmailConversationController
    /// </summary>
    /// 

    [Route("api/[controller]")]
    [ApiController]
    public class InternalHistoryController : Controller
    {
        private IChoiceRepository _choiceRepoistory;

        /// <summary>
        /// ID
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public InternalHistoryController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All GetInternalHistory
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<InternalHistoryDTO> GetInternalHistory()
        {
            return Ok(_choiceRepoistory.GetInternalHistory());
        }

       
        /// <summary>
        /// Get GetById by CRMPartnerId
        /// </summary>
        /// <param name="BookingID"></param>
        /// <returns></returns> 
        [Route("InternalHistory/{BookingID}")]
        [HttpGet()]
        public ActionResult<InternalHistoryDTO> GetById(string BookingID)
        {
            return _choiceRepoistory.GetInternalHistory().FirstOrDefault(c => c.BookingID == Convert.ToInt32(BookingID));
        }

        /// <summary>
        /// Update UpdateInternalHistoryDTOy
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="InternalHistoryDTO"></param>
        /// <returns></returns>


        [HttpPut()]
        [Route("UpdateInternalHistoryDTOy/{ID:int}")]
        public IActionResult UpdateInternalHistoryDTO(int ID, [FromBody] InternalHistoryDTO InternalHistoryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (InternalHistoryDTO == null)
            {
                return BadRequest();
            }

            var objInternalHistoryDTO = _choiceRepoistory.GetInternalHistory().Find(c => c.ID==ID);

            if (objInternalHistoryDTO == null)
            {
                return BadRequest();
            }

            objInternalHistoryDTO = InternalHistoryDTO;

            _choiceRepoistory.Complete();
            return NoContent();
        }


        /// <summary>
        /// Creating InternalHistoryDTO
        /// </summary>
        /// <param name="InternalHistoryDTO"></param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult InternalHistory([FromBody] InternalHistoryDTO InternalHistoryDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (InternalHistoryDTO == null)
            {
                return BadRequest();
            }

            var checkInternalHistoryDTOIdinDb = _choiceRepoistory.GetInternalHistory().Find(c => c.ID == InternalHistoryDTO.ID);

            if (checkInternalHistoryDTOIdinDb != null)
            {
                return BadRequest();
            }

            InternalHistory newlyInternalHistoryDTO = new InternalHistory()
            {
                ID = InternalHistoryDTO.ID,
                InternalHistroy = InternalHistoryDTO.InternalHistroy,
                BookingID = InternalHistoryDTO.BookingID,
               
            };
            _choiceRepoistory.SetInternalHistory(newlyInternalHistoryDTO);
            _choiceRepoistory.Complete();
            return CreatedAtRoute("GetInternalHistory", new { name = newlyInternalHistoryDTO.InternalHistroy }, newlyInternalHistoryDTO);
        }


    }
}


