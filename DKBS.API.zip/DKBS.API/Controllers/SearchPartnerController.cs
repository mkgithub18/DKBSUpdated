﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using DKBS.DTO;
using DKBS.DTO.CoursePackage;
using DKBS.DTO.Search;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DKBS.API.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class SearchPartnerController : ControllerBase
    {
        private IChoiceRepository _choiceRepository;
        private IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        public SearchPartnerController(IChoiceRepository choiceRepository, IMapper mapper)
        {
            _choiceRepository = choiceRepository;
            _mapper = mapper;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Search([FromBody] SearchPartnerDTO searchPartnerDTO)
        {
            if (searchPartnerDTO == null)
                return BadRequest();

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            List<PartnerCoursePackage> partnerCoursePackages = new List<PartnerCoursePackage>();
            List<PartnerCoursePackageDTO> partnerCoursePackageDtos = new List<PartnerCoursePackageDTO>();
            List<PartnerEmployeeDTO> partnerEmployeeDTOs = new List<PartnerEmployeeDTO>();
            List<PartnerCenterInfo> partnerCenterInfos = new List<PartnerCenterInfo>();
            List<CRMPartnerDTO> crmPartnerDTOs = new List<CRMPartnerDTO>();
            List<SearchPartnerResultDTO> searchPartnerResultDTOs = new List<SearchPartnerResultDTO>();
            List<int> partnerIdList = new List<int>();

            try
            {
                //Stpe 1: Get CRMPartner first based on partner type and regions
                var crmPartnersInDb = _choiceRepository.GetAll<CRMPartner>(x => x.Partnertype == searchPartnerDTO.PartnerType
                                    && x.Regions == searchPartnerDTO.Regions);

                //Step2 : Gets the crm partner course package for the crmpartners
                foreach (var crmPartner in crmPartnersInDb)
                {
                    var t = _choiceRepository.GetAll<PartnerCoursePackage>().ToList();
                    var partnerCoursePackageItems = _choiceRepository.GetAll<PartnerCoursePackage>()
                                                .Where(x => x.CrmPartnerId == crmPartner.CRMPartnerId
                                                && x.Offered!=null && x.Offered==true);

                    if (partnerCoursePackageItems.Any())
                    {
                        partnerCoursePackages.Add(partnerCoursePackageItems.FirstOrDefault());
                    }
                }

                //Step3 : check wether the partnerCenterInfo provides these ameneties
                foreach (var partnerCoursePackage in partnerCoursePackages)
                {
                    var query = _choiceRepository.GetAll<PartnerCenterInfo>()
                                 .Where(x => x.CrmPartnerId == partnerCoursePackage.CrmPartnerId
                                 && x.TotalRooms == searchPartnerDTO.TotalRooms
                                 && x.GroupRooms == searchPartnerDTO.GroupRooms
                                 && x.MaxSpaceAtRowOfChairs == searchPartnerDTO.MaxSpaceAtRowOfChairs
                                 && x.MaxspaceAtTables == searchPartnerDTO.MaxspaceAtTables).AsQueryable();

                    foreach (var refereshmentItemId in searchPartnerDTO.RefreshmentList)
                    {
                        var d = _choiceRepository.GetRefreshments();
                        var refereshmentEntryInDb = _choiceRepository.GetById<Refreshment>(refereshmentItemId);
                        if (refereshmentEntryInDb != null)
                        {
                            var refereshmentName = refereshmentEntryInDb.Name;
                            query = query.Where(GetDynamicLinqExpressionQuery(refereshmentName));
                        }
                    }

                    var res = query.ToList();
                    if (res.Any())
                    {
                        partnerCenterInfos.AddRange(res);
                    }
                }

                //Step4 : Prepare the final list of crm partner dto
                foreach (var partnerCenterInfo in partnerCenterInfos)
                {
                    var crmPartner = _choiceRepository.GetById<CRMPartner>(x => x.CRMPartnerId == partnerCenterInfo.CrmPartnerId);
                    CRMPartnerDTO cRMPartnerDTO = _mapper.Map<CRMPartner, CRMPartnerDTO>(crmPartner);
                    crmPartnerDTOs.Add(cRMPartnerDTO);
                }

                // now based on final list of crm partner dto prepare PartnerCoursePackage and PartnerEmployee
                foreach (var crmPartner in crmPartnerDTOs)
                {
                    SearchPartnerResultDTO searchPartnerResultDTO = new SearchPartnerResultDTO();
                    searchPartnerResultDTO.CRMPartnerDTO = crmPartner;
                    foreach (var partnerCoursePackage in partnerCoursePackages.Where(x => x.CrmPartnerId == crmPartner.CRMPartnerId))
                    {
                        PartnerCoursePackageDTO partnerCoursePackageDto = _mapper.Map<PartnerCoursePackage, PartnerCoursePackageDTO>(partnerCoursePackage);
                        partnerCoursePackageDtos.Add(partnerCoursePackageDto);
                    }

                    foreach (var partnerEmployee in _choiceRepository.GetAll<PartnerEmployee>(x => x.CRMPartnerId == crmPartner.CRMPartnerId))
                    {
                        PartnerEmployeeDTO partnerEmployeeDTO = _mapper.Map<PartnerEmployee, PartnerEmployeeDTO>(partnerEmployee);
                        partnerEmployeeDTOs.Add(partnerEmployeeDTO);
                    }

                    searchPartnerResultDTO.PartnerCoursePackageDtos = partnerCoursePackageDtos;
                    searchPartnerResultDTO.PartnerEmployeeDTOs = partnerEmployeeDTOs;
                    searchPartnerResultDTOs.Add(searchPartnerResultDTO);
                }
            }
            catch (Exception ex)
            {
                // log it here in future add appropriate message
            }

            return Ok(searchPartnerResultDTOs);
        }


        private Expression<Func<PartnerCenterInfo, bool>> GetDynamicLinqExpressionQuery(string propertyName)
        {
            var parameter = Expression.Parameter(typeof(PartnerCenterInfo), "p");
            var linqExpressionQuery = Expression.Lambda<Func<PartnerCenterInfo, bool>>(
                Expression.Equal(
                    Expression.Property(parameter, propertyName),
                    Expression.Constant(true,typeof(bool?))
                ),
                parameter
            );

            return linqExpressionQuery;
        }


    }

}