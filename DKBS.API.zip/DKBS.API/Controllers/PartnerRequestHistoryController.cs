﻿using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{
    /// <summary>
    /// EmailConversationController
    /// </summary>
    /// 

    [Route("api/[controller]")]
    [ApiController]
    public class PartnerRequestHistoryController : Controller
    {
        private IChoiceRepository _choiceRepoistory;

        /// <summary>
        /// PartnerCenterInfo_Id
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public PartnerRequestHistoryController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All GetPartnerRequestHistory
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<PartnerRequestHistoryDTO> GetPartnerRequestHistory()
        {
            return Ok(_choiceRepoistory.GetPartnerRequestHistory());
        }


        /// <summary>
        /// Get GetById by CRMPartnerId
        /// </summary>
        /// <param name="BookingID"></param>
        /// <returns></returns> 
        [Route("BookingID")]
        [HttpGet()]
        public ActionResult<PartnerRequestHistoryDTO> GetById(string BookingID)
        {
            return _choiceRepoistory.GetPartnerRequestHistory().FirstOrDefault(c => c.BookingID == BookingID);
        }

        /// <summary>
        /// Update UpdatePartnerCenterInfo
        /// </summary>
        /// <param name="PartnerRequestHistoryID"></param>
        /// <param name="PartnerRequestHistoryDTO"></param>
        /// <returns></returns>


        [HttpPut()]
        [Route("UpdatePartnerRequestHistory/{EmailConversationID:int}")]
        public IActionResult UpdatePartnerRequestHistory(int PartnerRequestHistoryID, [FromBody] PartnerRequestHistoryDTO PartnerRequestHistoryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (PartnerRequestHistoryDTO == null)
            {
                return BadRequest();
            }

            var PartnerRequestHistory = _choiceRepoistory.GetPartnerRequestHistory().Find(c => c.PartnerRequestHistoryID == PartnerRequestHistoryID);

            if (PartnerRequestHistory == null)
            {
                return BadRequest();
            }

            PartnerRequestHistory = PartnerRequestHistoryDTO;

            _choiceRepoistory.Complete();
            return NoContent();
        }


        /// <summary>
        /// Creating PartnerRequestHistory
        /// </summary>
        /// <param name="PartnerRequestHistoryDTO"></param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult PartnerRequestHistory([FromBody] PartnerRequestHistoryDTO PartnerRequestHistoryDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (PartnerRequestHistoryDTO == null)
            {
                return BadRequest();
            }

            var checkPartnerRequestHistoryIdinDb = _choiceRepoistory.GetPartnerRequestHistory().Find(c => c.PartnerRequestHistoryID == PartnerRequestHistoryDTO.PartnerRequestHistoryID);

            if (checkPartnerRequestHistoryIdinDb != null)
            {
                return BadRequest();
            }

            PartnerRequestHistory newlyPartnerRequestHistory = new PartnerRequestHistory()
            {
                PartnerRequestHistoryID = PartnerRequestHistoryDTO.PartnerRequestHistoryID,
                PartnerRequestName = PartnerRequestHistoryDTO.PartnerRequestName,
                BookingID = PartnerRequestHistoryDTO.BookingID,
                Comments = PartnerRequestHistoryDTO.Comments,
                InternalNoteNotify = PartnerRequestHistoryDTO.InternalNoteNotify,
                ScheduleAction = PartnerRequestHistoryDTO.ScheduleAction,
                CopyToCloseRemark = PartnerRequestHistoryDTO.CopyToCloseRemark,
                PlannedStart = PartnerRequestHistoryDTO.PlannedStart,
                PlannedEnd = PartnerRequestHistoryDTO.PlannedEnd,
                toMessage = PartnerRequestHistoryDTO.toMessage,
                CreatedDate = PartnerRequestHistoryDTO.CreatedDate,
                CreatedBy = PartnerRequestHistoryDTO.CreatedBy,
                LastModified = PartnerRequestHistoryDTO.LastModified,
                LastModifiedBY = PartnerRequestHistoryDTO.LastModifiedBY,
                SharepointID = PartnerRequestHistoryDTO.SharepointID,
            };         
            _choiceRepoistory.SetPartnerRequestHistory(newlyPartnerRequestHistory);
            _choiceRepoistory.Complete();
            return CreatedAtRoute("GetPartnerRequestHistory", new { name = newlyPartnerRequestHistory.PartnerRequestName }, newlyPartnerRequestHistory);
        }


    }
}


