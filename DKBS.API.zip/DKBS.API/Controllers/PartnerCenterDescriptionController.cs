﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DKBS.API.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PartnerCenterDescriptionController : ControllerBase
    {
        private readonly IChoiceRepository _choiceRepoistory;
        private IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="choiceReposiroty"></param>
        /// <param name="mapper"></param>
        public PartnerCenterDescriptionController(IChoiceRepository choiceReposiroty, IMapper mapper)
        {
            _choiceRepoistory = choiceReposiroty;
            _mapper = mapper;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        // GET: api/<controller>
        [HttpGet]
        public ActionResult<PartnerCenterDescriptionDTO> GetPartnerCenterDescription()
        {
            return Ok(_choiceRepoistory.GetPartnerCenterDescriptions());
        }

        /// <summary>
        /// Get partner details by partnerCenterDescriptionId
        /// </summary>
        /// <param name="partnerCenterDescriptionId"></param>
        /// <returns></returns>
        [HttpGet("{partnerCenterDescriptionId}", Name = "GetPartnerCenterDescriptionId")]

        public ActionResult<PartnerCenterDescriptionDTO> GetPartnerCenterDescriptionId(int partnerCenterDescriptionId)
        {
            //return _choiceRepoistory.GetPartnerCenterDescriptions().FirstOrDefault(c => c.PartnerCenterDescriptionId == partnerCenterDescriptionId);

            var ObjPartnerCenterDescriptions = _choiceRepoistory.GetPartnerCenterDescriptions().FirstOrDefault(c => c.PartnerCenterDescriptionId == partnerCenterDescriptionId);


            if (ObjPartnerCenterDescriptions == null)
            {
                return NotFound(partnerCenterDescriptionId);
            }

            // var returnval = _mapper.Map<PartnerCenterDescription, PartnerCenterDescriptionDTO>(ObjPartnerCenterDescriptions);

            return Ok(ObjPartnerCenterDescriptions);


        }

        // POST api/<controller>

        /// <summary>
        /// Creating PartnerCenterDescription
        /// </summary>
        /// <param name="partnerCenterDescriptionDto"></param>
        /// <response code="201">Returns the newly created partner</response>
        /// <response code="400">If the item is null</response>            
        /// <returns>newly created PartnerCenterDescription</returns>
        ///

        //  TODO : Remove this 
        [HttpPost("")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public ActionResult<IEnumerable<PartnerCenterDescriptionDTO>> CreatePartnerCenterDescription([FromBody] PartnerCenterDescriptionDTO partnerCenterDescriptionDto)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (partnerCenterDescriptionDto == null)
            {
                return BadRequest();
            }

            var checkPartnerIdinDb = _choiceRepoistory.GetPartnerCenterDescriptions().Find(c => c.PartnerCenterDescriptionId == partnerCenterDescriptionDto.PartnerCenterDescriptionId);

            if (checkPartnerIdinDb != null)
            {
                return BadRequest();
            }

            PartnerCenterDescription newlyCreatedPartnerCenterDescription = new PartnerCenterDescription()
            {
                PartnerCenterDescriptionId = partnerCenterDescriptionDto.PartnerCenterDescriptionId,
                CRMPartnerId = partnerCenterDescriptionDto.CRMPartnerId,
                Rooms = partnerCenterDescriptionDto.Rooms,
                Capacity = partnerCenterDescriptionDto.Capacity,
                Facilities = partnerCenterDescriptionDto.Facilities,
                Activities = partnerCenterDescriptionDto.Activities,
                ApprovalStatus = partnerCenterDescriptionDto.ApprovalStatus,
                TextforQuotationforEmail = partnerCenterDescriptionDto.TextforQuotationforEmail,
                Transportation = partnerCenterDescriptionDto.Transportation,
                Description = partnerCenterDescriptionDto.Description,
                AdditionalIncluded = partnerCenterDescriptionDto.AdditionalIncluded,
                Language = partnerCenterDescriptionDto.Language,
                ApprovalStatusId = partnerCenterDescriptionDto.ApprovalStatusId,
                CreatedDate = partnerCenterDescriptionDto.CreatedDate,
                CreatedBy = partnerCenterDescriptionDto.CreatedBy,
                LastModified = partnerCenterDescriptionDto.LastModified,
                LastModifiedBY = partnerCenterDescriptionDto.LastModifiedBY
            };
            var destination = _mapper.Map<PartnerCenterDescription, PartnerCenterDescriptionDTO>(newlyCreatedPartnerCenterDescription);


            //_choiceRepoistory.GetPartnerCenterDescriptions().Add(destination);
            //_choiceRepoistory.Complete();

            _choiceRepoistory.SetPartnerCenterDescriptions(newlyCreatedPartnerCenterDescription);
            _choiceRepoistory.Complete();
            return CreatedAtRoute("GetPartnerCenterDescriptionId", new { newlyCreatedPartnerCenterDescription.PartnerCenterDescriptionId }, partnerCenterDescriptionDto);

            // return CreatedAtRoute("GetPartnerByAccountId", new { newPartner.AccountId }, dto);


        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="partnerCenterDescriptionId"></param>
        /// <param name="partnerCenterDescriptionDto"></param>
        /// <returns></returns>
        // PUT api/<controller>/5
        [HttpPut("{partnerCenterDescriptionId}")]
        public IActionResult UpdatePartnerCenterDescription(int partnerCenterDescriptionId, [FromBody] PartnerCenterDescriptionDTO partnerCenterDescriptionDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (partnerCenterDescriptionDto == null)
            {
                return BadRequest();
            }

            var partnerCenterDescription = _choiceRepoistory.GetPartnerCenterDescriptions().Find(c => c.PartnerCenterDescriptionId == partnerCenterDescriptionId);

            if (partnerCenterDescription == null)
            {
                return BadRequest();
            }

            partnerCenterDescription = partnerCenterDescriptionDto;

            _choiceRepoistory.Complete();
            return NoContent();
        }

    }
}
