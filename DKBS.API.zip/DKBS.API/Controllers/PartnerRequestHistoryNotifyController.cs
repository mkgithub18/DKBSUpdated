﻿using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{


    /// <summary>
    /// PartnerRequestHistoryNotifyController
    /// </summary>
    /// 

    [Route("api/[controller]")]
    [ApiController]
    public class PartnerRequestHistoryNotifyController : Controller
    {
        private IChoiceRepository _choiceRepoistory;

        /// <summary>
        /// PartnerCenterInfo_Id
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public PartnerRequestHistoryNotifyController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All PartnerCenterInfo
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<PartnerRequestHistoryNotifyDTO> GetSRInternalNotify()
        {
            return Ok(_choiceRepoistory.GetPartnerRequestHistoryNotify());
        }


        /// <summary>
        /// Get SRInternalNotifyDTO by ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns> 
        [Route("ID")]
        [HttpGet()]
        public ActionResult<PartnerRequestHistoryNotifyDTO> GetById(int ID)
        {
            return _choiceRepoistory.GetPartnerRequestHistoryNotify().FirstOrDefault(c => c.ID == ID);
        }

     

    }
}
