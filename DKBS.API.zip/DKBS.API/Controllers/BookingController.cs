﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using DKBS.Domain;
using DKBS.Domain.CoursePackage;
using DKBS.DTO;
using DKBS.DTO.Booking;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DKBS.API.Controllers
{

    /// <summary>
    /// Booking
    /// </summary>
    [Route("BookingController")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private IChoiceRepository _choiceRepoistory;
        private IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        /// <param name="mapper"></param>
        public BookingController(IChoiceRepository choiceRepoistory, IMapper mapper)
        {
            _choiceRepoistory = choiceRepoistory;
            _mapper = mapper;
        }

        /// <summary>
        /// Get All Bookings
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<BookingDTO> GetBookings()
        {
            return Ok(_choiceRepoistory.GetAllBookings());
        }

        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingId}")]
        public ActionResult<BookingReferenceDTO> GetBookingReference(int bookingId)
        {
            var temp = _choiceRepoistory.GetBookingReferences().FirstOrDefault(c => c.BookingDTO.BookingId == bookingId);
            return temp;
        }


        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingId}")]
        public ActionResult<BookingAlternativeServiceDTO> GetBookingAlternativeService(int bookingId)
        {
            return _choiceRepoistory.GetBookingAlternativeServices().FirstOrDefault(c => c.BookingId == bookingId);
        }

        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingAndStatusId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingAndStatusId}")]
        public ActionResult<BookingAndStatusDTO> GetBookingAndStatusById(int bookingAndStatusId)
        {
            return _choiceRepoistory.GetBookingAndStatuses().FirstOrDefault(c => c.BookingAndStatusId == bookingAndStatusId);
        }

        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingId}")]
        public ActionResult<BookingArrangementTypeDTO> GetBookingArrangementType(int bookingId)
        {
            return _choiceRepoistory.GetBookingArrangementTypes().FirstOrDefault(c => c.BookingId == bookingId);
        }

        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingId}")]
        public ActionResult<BookingRegionDTO> GetBookingRegion(int bookingId)
        {
            return _choiceRepoistory.GetBookingRegions().FirstOrDefault(c => c.BookingId == bookingId);
        }

        /// <summary>
        /// Get bookingReference by booking id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("[action]/{bookingId}")]
        public ActionResult<BookingRoomDTO> GetBookingRooms(int bookingId)
        {
            return _choiceRepoistory.GetBookingRooms().FirstOrDefault(c => c.BookingId == bookingId);
        }

        /// <summary>
        /// Get booking by id
        /// </summary>
        /// <param name="bookingId"></param>
        /// <returns></returns>
        [HttpGet("{bookingId}", Name = "GetBookingById")]
        public ActionResult<BookingDTO> GetBookingById(int bookingId)
        {
            return _choiceRepoistory.GetBookingById(bookingId);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="bookingId"></param>
        /// <param name="putBookingViewModel"></param>
        /// <returns></returns>
        [HttpPut("{bookingId}")]
        public IActionResult UpdateBooking(int bookingId, [FromBody] PutBookingViewModel putBookingViewModel)
        {

            IList<int> coursePackageIdList = new List<int>();

            if (putBookingViewModel == null)
            {
                // TODO: improve the error messages details
                ModelState.AddModelError("Booking", $"Booking object cannot not be null");
                return BadRequest(ModelState);
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var booking = _choiceRepoistory.GetById<Booking>(bookingId);

            if (booking == null)
            {
                ModelState.AddModelError("Booking", $"There is no entry found for BookingId {bookingId}.");
                return BadRequest(ModelState);
            }

            var allBookingRegionInDb = _choiceRepoistory.GetAll<BookingRegion>().Where(x => x.BookingId == booking.BookingId).ToList();
            foreach (var bookingRegionDetail in allBookingRegionInDb)
            {
                _choiceRepoistory.Remove<BookingRegion>(bookingRegionDetail);
            }


            var allBookingRoomInDb = _choiceRepoistory.GetAll<BookingRoom>().Where(x => x.BookingId == booking.BookingId).ToList();
            foreach (var bookingRoom in allBookingRoomInDb)
            {
                var tableSets = _choiceRepoistory.GetAll<TableSet>().Where(x => x.TableSetId == bookingRoom.TableSetId);
                foreach (var tableSet in tableSets)
                {
                    _choiceRepoistory.Remove<TableSet>(tableSet);
                }
                _choiceRepoistory.Remove<BookingRoom>(bookingRoom);
            }


            foreach (var item in putBookingViewModel.RegionIds)
            {
                BookingRegion bookingRegion = new BookingRegion();
                var region = _choiceRepoistory.GetById<Region>(item);
                bookingRegion.BookingId = booking.BookingId;
                bookingRegion.RegionId = region.RegionId;
                _choiceRepoistory.Attach(bookingRegion);
            }


            foreach (var item in putBookingViewModel.BookingRoomViewModel)
            {
                TableSet tableSet = new TableSet()
                {
                    LastModified = item.TableSetViewModel.LastModified,
                    LastModifiedBy = item.TableSetViewModel.LastModifiedBy,
                    TableSetName = item.TableSetViewModel.TableSetName
                };

                BookingRoom bookingRoom = new BookingRoom()
                {
                    FromDate = item.FromDate,
                    LocationAttraction = item.LocationAttraction,
                    NumberOfRooms = item.NumberOfRooms,
                    PerPerson = item.PerPerson,
                    TableSet = tableSet,
                    ToDate = item.ToDate,
                    BookingId = booking.BookingId
                };

                _choiceRepoistory.Attach(bookingRoom);
            }

            booking.CRMPartnerId = putBookingViewModel.CRMPartnerId;
            booking.Arrival = putBookingViewModel.Arrival;
            booking.BookingAndStatusId = putBookingViewModel.BookingAndStatusId;
            booking.CampaignId = putBookingViewModel.CampaignId;
            booking.CancellationReasonId = putBookingViewModel.CancellationReasonId;
            booking.CauseOfRemovalId = putBookingViewModel.CauseOfRemovalId;
            booking.ContactPersonId = putBookingViewModel.ContactPersonId;
            booking.CustomerId = putBookingViewModel.CustomerId;
            booking.Departure = putBookingViewModel.Departure;
            booking.FlexibleDates = putBookingViewModel.FlexibleDates;
            booking.FlowId = putBookingViewModel.FlowId;
            booking.InternalHistory = putBookingViewModel.InternalHistory;
            booking.LeadOfOriginId = putBookingViewModel.LeadOfOriginId;
            booking.MailLanguageId = putBookingViewModel.MailLanguageId;
            booking.ParticipantTypeId = putBookingViewModel.ParticipantTypeId;
            booking.PartnerTypeId = putBookingViewModel.PartnerTypeId;
            booking.PurposeId = putBookingViewModel.PurposeId;
            booking.TableTypeId = putBookingViewModel.TableTypeId;

            // First delete all existing booking arrangement type
            var allBookingArrangementTypeInDb = _choiceRepoistory.GetAll<BookingArrangementType>().Where(x => x.BookingId == booking.BookingId).ToList();
            foreach (var bookingArrangement in allBookingArrangementTypeInDb)
            {
                _choiceRepoistory.Remove<BookingArrangementType>(bookingArrangement);
            }


            // First delete all existing booking BookingAlternativeService
            var allBookingAlternativeServiceInDb = _choiceRepoistory.GetAll<BookingAlternativeService>().Where(x => x.BookingId == booking.BookingId).ToList();
            foreach (var bookingAlternativeService in allBookingAlternativeServiceInDb)
            {
                _choiceRepoistory.Remove<BookingAlternativeService>(bookingAlternativeService);
            }

            //First delete all the procedures associate with this booking
            var allProceduresInDb = _choiceRepoistory.GetAll<Procedure>().Where(x => x.BookingId == booking.BookingId).ToList();
            foreach (var procedure in allProceduresInDb)
            {
                _choiceRepoistory.Remove<Procedure>(procedure);
            }


            foreach (var item in putBookingViewModel.BookingArrangementTypeViewModel)
            {
                coursePackageIdList.Add(item.CoursePackageId);

                BookingArrangementType bookingArrangementType = new BookingArrangementType()
                {
                    BookingId = booking.BookingId,
                    FromDate = item.FromDate,
                    NumberOfParticipants = item.NumberOfParticipants,
                    CoursePackageId = item.CoursePackageId,
                    ToDate = item.ToDate
                };

                _choiceRepoistory.Attach(bookingArrangementType);
            }


            _choiceRepoistory.Complete();

            // Create procedures again TODO: Check wether is required or will have another flow?
            CreateProcedure(putBookingViewModel, coursePackageIdList, booking);

            foreach (var item in putBookingViewModel.BookingAlternativeServiceViewModel)
            {
                BookingAlternativeService bookingAlternativeService = new BookingAlternativeService()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Description = item.Description,
                    LastModifiedBy = item.LastModifiedBy,
                    NumberOfPieces = item.NumberOfPieces,
                    BookingId = booking.BookingId,
                    LastModified = item.LastModified,

                };

                _choiceRepoistory.Attach(bookingAlternativeService);
            }

            _choiceRepoistory.Complete();

            return NoContent();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="postBookingViewModel"></param>
        /// <returns></returns>
        [HttpPost()]
        public IActionResult CreateBooking([FromBody] PostBookingViewModel postBookingViewModel)
        {
            #region Intenitonally commented out
            //if (postBookingViewModel == null)
            //    return BadRequest();

            //if (!ModelState.IsValid)
            //{
            //    return BadRequest(ModelState);
            //}
            #endregion

            Booking newlyCreatedBooking = _mapper.Map<PostBookingViewModel, Booking>(postBookingViewModel);

            // TODO : change it to some other value currently commented below code
            //newlyCreatedBooking.FlowId = _choiceRepoistory.GetAll<Flow>().FirstOrDefault().FlowId;
            //newlyCreatedBooking.BookingAndStatusId = _choiceRepoistory.GetAll<BookingAndStatus>().FirstOrDefault().BookingAndStatusId;
            //newlyCreatedBooking.MailLanguageId = _choiceRepoistory.GetAll<MailLanguage>().FirstOrDefault().MailLanguageId;


            _choiceRepoistory.Attach<Booking>(newlyCreatedBooking);
            _choiceRepoistory.Complete();

            foreach (var item in postBookingViewModel.BookingRoomViewModel)
            {
                TableSet tableSet = new TableSet()
                {
                    LastModified = item.TableSetViewModel.LastModified,
                    LastModifiedBy = item.TableSetViewModel.LastModifiedBy,
                    TableSetName = item.TableSetViewModel.TableSetName,
                };

                BookingRoom bookingRoom = new BookingRoom()
                {
                    FromDate = item.FromDate,
                    LocationAttraction = item.LocationAttraction,
                    NumberOfRooms = item.NumberOfRooms,
                    PerPerson = item.PerPerson,
                    TableSet = tableSet,
                    ToDate = item.ToDate,
                    BookingId = newlyCreatedBooking.BookingId
                };

                _choiceRepoistory.Attach(bookingRoom);
            }
            _choiceRepoistory.Complete();

            foreach (var item in postBookingViewModel.BookingAlternativeServiceViewModel)
            {
                BookingAlternativeService bookingAlternativeService = new BookingAlternativeService()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    Description = item.Description,
                    LastModifiedBy = item.LastModifiedBy,
                    NumberOfPieces = item.NumberOfPieces,
                    BookingId = newlyCreatedBooking.BookingId,
                    LastModified = item.LastModified,

                };

                _choiceRepoistory.Attach(bookingAlternativeService);

            }
            _choiceRepoistory.Complete();

            IList<int> coursePackageIdList = new List<int>();

            foreach (var item in postBookingViewModel.BookingArrangementTypeViewModel)
            {
                coursePackageIdList.Add(item.CoursePackageId);
                BookingArrangementType bookingArrangementType = new BookingArrangementType()
                {
                    BookingId = newlyCreatedBooking.BookingId,
                    FromDate = item.FromDate,
                    NumberOfParticipants = item.NumberOfParticipants,
                    CoursePackageId = item.CoursePackageId,
                    ToDate = item.ToDate
                };

                _choiceRepoistory.Attach(bookingArrangementType);
            }

            _choiceRepoistory.Complete();

            foreach (var item in postBookingViewModel.RegionIds)
            {
                BookingRegion bookingRegion = new BookingRegion();
                var region = _choiceRepoistory.GetById<Region>(item);
                bookingRegion.BookingId = newlyCreatedBooking.BookingId;
                bookingRegion.RegionId = region.RegionId;
                _choiceRepoistory.Attach(bookingRegion);
            }

            _choiceRepoistory.Complete();

            CreateProcedure(postBookingViewModel, coursePackageIdList, newlyCreatedBooking);

            return CreatedAtRoute("GetBookingById", new { bookingId = newlyCreatedBooking.BookingId }, newlyCreatedBooking);
        }

        private void CreateProcedure(BookingViewModelBase bookingViewModelBase, IList<int> coursePackageIdList, Booking booking)
        {
            for (int i = 0; i < bookingViewModelBase.CrmPartnerIds.Count; i++)
            {
                // Getting the price for partner 
                decimal? totalPrice = GetTotalPrice(bookingViewModelBase.CrmPartnerIds[i], coursePackageIdList);

                // This is for default data only
                //var procedureReviewTypeId = _choiceRepoistory.GetAll<ProcedureReviewType>().FirstOrDefault().ProcedureReviewTypeId;
                Procedure procedure = new Procedure()
                {
                    BookingId = booking.BookingId,
                    CrmPartnerId = bookingViewModelBase.CrmPartnerIds[i],
                    ProcedureTitle = "Procedure_" + booking.BookingId,
                    TotalPrice = 0,
                    SystemPrice = 0,
                    LastModified = DateTime.UtcNow,
                    CreatedDate = DateTime.Now,
                };

                _choiceRepoistory.Attach<Procedure>(procedure);
            }

            _choiceRepoistory.Complete();
        }

        //Move it out to seperate class
        private decimal? GetTotalPrice(int crmPartnerId, IList<int> coursePackageIdList)
        {
            foreach (var CoursePackageId in coursePackageIdList)
            {
                var partnerCoursePackage = _choiceRepoistory
                                .GetById<PartnerCoursePackage>
                                (x => x.CrmPartnerId == crmPartnerId
                                && x.CoursePackageId == CoursePackageId);
                if (partnerCoursePackage != null)
                {
                    return partnerCoursePackage.Price;
                }
            }

            return 0;
        }
    }

}