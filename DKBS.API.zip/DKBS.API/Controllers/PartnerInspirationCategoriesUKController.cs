﻿using DKBS.Domain;
using DKBS.DTO;
using DKBS.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DKBS.API.Controllers
{

    /// <summary>
    /// PartnerInspirationCategoriesUKController
    /// </summary>
    /// 


    [Route("api/[controller]")]
    [ApiController]
    public class PartnerInspirationCategoriesUKController : Controller
    {
        private IChoiceRepository _choiceRepoistory;

        /// <summary>
        /// PartnerCenterRoomInfo
        /// </summary>
        /// <param name="choiceRepoistory"></param>
        public PartnerInspirationCategoriesUKController(IChoiceRepository choiceRepoistory)
        {
            _choiceRepoistory = choiceRepoistory;
        }

        /// <summary>
        /// Get All GetPartnerInspirationCategoriesUK
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult<PartnerInspirationCategoriesUK> GetPartnerInspirationCategoriesUK()
        {
            return Ok(_choiceRepoistory.GetPartnerInspirationCategoriesUK());
        }

        /// <summary>
        /// Get PartnerInspirationCategoriesUK_Id by id
        /// </summary>
        /// <param name="PartnerInspirationCategoriesUK_Id"></param>
        /// <returns></returns>
        [HttpGet("{PartnerInspirationCategoriesUK_Id}")]
        public ActionResult<PartnerInspirationCategoriesUKDTO> GetPartnerInspirationCategoriesUKId(int PartnerInspirationCategoriesUK_Id)
        {
            return _choiceRepoistory.GetPartnerInspirationCategoriesUK().FirstOrDefault(c => c.PartnerInspirationCategoriesUKId == PartnerInspirationCategoriesUK_Id);
        }

        /// <summary>
        /// Get PartnerInspirationCategoriesUK_Id by PartnerId
        /// </summary>
        /// <param name="crmPartnerId"></param>
        /// <returns></returns>
        [Route("GetByPartnerId")]
        [HttpGet()]
        public ActionResult<PartnerInspirationCategoriesUKDTO> GetById(int crmPartnerId)
        {
            return _choiceRepoistory.GetPartnerInspirationCategoriesUK().FirstOrDefault(c => c.CRMPartnerId == crmPartnerId);
        }


        /// <summary>y
        /// Update UpdatePartnerCenterInfo
        /// </summary>
        /// <param name="PartnerInspirationCategoriesUK_Id"></param>
        /// <param name="PartnerInspirationCategoriesUKDTO"></param>
        /// <returns></returns>

        [HttpPut("{PartnerInspirationCategoriesUK_Id}")]
        public IActionResult UpdatepartnerCenterRoomInfo(int PartnerInspirationCategoriesUK_Id, [FromBody] PartnerInspirationCategoriesUKDTO PartnerInspirationCategoriesUKDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (PartnerInspirationCategoriesUKDTO == null)
            {
                return BadRequest();
            }

            var PartnerInspirationCategoriesUK = _choiceRepoistory.GetPartnerInspirationCategoriesUK().Find(c => c.PartnerInspirationCategoriesUKId == PartnerInspirationCategoriesUK_Id);

            if (PartnerInspirationCategoriesUK == null)
            {
                return BadRequest();
            }

            PartnerInspirationCategoriesUK = PartnerInspirationCategoriesUKDTO;

            _choiceRepoistory.Complete();
            return NoContent();
        }


        /// <summary>
        /// Creating PartnerCenterRoomInfo
        /// </summary>
        /// <param name="PartnerInspirationCategoriesUKDTO"></param>
        /// <returns></returns>
        // GET api/PartnerInspirationCategoriesUK/{PartnerInspirationCategoriesUK}
        [HttpPost]
        public ActionResult<IEnumerable<PartnerInspirationCategoriesUKDTO>> PartnerInspirationCategoriesUK([FromBody] PartnerInspirationCategoriesUKDTO PartnerInspirationCategoriesUKDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            if (PartnerInspirationCategoriesUKDTO == null)
            {
                return BadRequest();
            }

            var checkPartnerCenterRoomInfoIdinDb = _choiceRepoistory.GetPartnerInspirationCategoriesUK().Find(c => c.PartnerInspirationCategoriesUKId == PartnerInspirationCategoriesUKDTO.PartnerInspirationCategoriesUKId);

            if (checkPartnerCenterRoomInfoIdinDb != null)
            {
                return BadRequest();
            }

            PartnerInspirationCategoriesUK newlyPartnerInspirationCategoriesUKDTO = new PartnerInspirationCategoriesUK()
            {
                PartnerInspirationCategoriesUKId = PartnerInspirationCategoriesUKDTO.PartnerInspirationCategoriesUKId,
                CRMPartnerId = PartnerInspirationCategoriesUKDTO.CRMPartnerId,
                // Room_Name = PartnerInspirationCategoriesUKDTO.Room_Name,
                Heading = PartnerInspirationCategoriesUKDTO.Heading,
                Description = PartnerInspirationCategoriesUKDTO.Description,
                Price = PartnerInspirationCategoriesUKDTO.Price,
                ApprovalStatus = PartnerInspirationCategoriesUKDTO.ApprovalStatus,
                CreatedDate = PartnerInspirationCategoriesUKDTO.CreatedDate,
                CreatedBy = PartnerInspirationCategoriesUKDTO.CreatedBy,
                LastModified = PartnerInspirationCategoriesUKDTO.LastModified,
                LastModifiedBY = PartnerInspirationCategoriesUKDTO.LastModifiedBY
            };
  
            _choiceRepoistory.SetpartnerInspirationCategoriesUK(newlyPartnerInspirationCategoriesUKDTO);
            _choiceRepoistory.Complete();

            return CreatedAtRoute("GetPartnerInspirationCategoriesUKId", new { name = newlyPartnerInspirationCategoriesUKDTO.PartnerInspirationCategoriesUKId }, PartnerInspirationCategoriesUKDTO);
        }

    }
}
