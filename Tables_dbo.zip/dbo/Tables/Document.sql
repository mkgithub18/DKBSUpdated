﻿CREATE TABLE [dbo].[Document]
(
	[DocumentId] INT NOT NULL PRIMARY KEY IDENTITY,
	[DocumentCategoryId] INT,
	[DcoumentName] NVARCHAR(255) NULL,
	[Details] NVARCHAR(2000) NULL,
	[ExpirationDate] DATETIME NULL,
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL
	CONSTRAINT [FKDocument_DocumentCategoryId] FOREIGN KEY (DocumentCategoryId) REFERENCES DocumentCategory(DocumentCategoryId),
)
