﻿CREATE TABLE [dbo].[BookingArrangementType]
(
	[BookingArrangementTypeId] INT NOT NULL PRIMARY KEY IDENTITY, 
	[BookingId] INT NOT NULL,
	[CoursePackageId] INT NOT NULL,
	[NumberOfParticipants] INT NOT NULL,
    [ToDate] DATETIME NULL,
	[FromDate] DATETIME NULL, 
    CONSTRAINT [FK_BookingArrangementType_Booking] FOREIGN KEY (BookingId) REFERENCES Booking(BookingId), 
    CONSTRAINT [FK_BookingArrangementType_CoursePackage] FOREIGN KEY (CoursePackageId) REFERENCES CoursePackage(CoursePackageId), 
    
)
