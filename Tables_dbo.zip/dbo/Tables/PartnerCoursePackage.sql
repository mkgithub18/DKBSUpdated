﻿CREATE TABLE [dbo].[PartnerCoursePackage]
(
	[PartnerCoursePackageId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [CRMPartnerId] INT NOT NULL, 
    [CoursePackageId] INT NOT NULL, 
    [Offered] BIT NULL, 
    [Price] DECIMAL(18, 2) NULL, 
    [ContentStatusId] INT ,
    [CreatedDate] DATETIME NULL, 
    [CreatedBy] NVARCHAR(50) NULL, 
    [LastModified] DATETIME NULL, 
    [LastModifiedBy] NVARCHAR(50) NULL, 
    CONSTRAINT [FK_PartnerCoursePackages_CRMPartner_CRMPartnerId] FOREIGN KEY ([CRMPartnerId]) REFERENCES [dbo].[CRMPartner] ([CRMPartnerId]),
	CONSTRAINT FK_PartnerCoursePackages_CoursePackage_CoursePackageId FOREIGN KEY (CoursePackageId) REFERENCES CoursePackage(CoursePackageId),
	CONSTRAINT [FK_PartnerCoursePackages_ContentStatus_ContentStatusId] FOREIGN KEY (ContentStatusId) REFERENCES [dbo].ContentStatus (ContentStatusId)
)
