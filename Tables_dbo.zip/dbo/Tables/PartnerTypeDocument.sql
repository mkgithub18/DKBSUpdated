﻿CREATE TABLE [dbo].[PartnerTypeDocument]
(
	[DocumentId] INT,
	[PartnerTypeId] INT,
	CONSTRAINT [FK_PartnerTypeDocument_DocumentId] FOREIGN KEY  (DocumentId) REFERENCES Document(DocumentId),
	CONSTRAINT [FK_PartnerTypeDocument_PartnerTypeId] FOREIGN KEY  (PartnerTypeId) REFERENCES PartnerType(PartnerTypeId),
	CONSTRAINT PK_PartnerTypeDocument PRIMARY KEY CLUSTERED (DocumentId, PartnerTypeId)
)
