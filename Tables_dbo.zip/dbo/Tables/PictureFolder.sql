﻿CREATE TABLE [dbo].[PictureFolder]
(
	[PictureFolderId] INT NOT NULL PRIMARY KEY IDENTITY,
	[FolderName] NVARCHAR(255),
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL
)
