﻿CREATE TABLE [dbo].[CoursePackage]
(
	[CoursePackageId] INT NOT NULL PRIMARY KEY IDENTITY,
	CoursePackageName NVARCHAR(255),
	CoursePackageNameEN  NVARCHAR(255),
	Offered BIT,
	Price DECIMAL(18,2),
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL
)
