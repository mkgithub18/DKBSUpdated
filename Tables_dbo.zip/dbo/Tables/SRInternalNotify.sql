﻿CREATE TABLE [dbo].[SRInternalNotify] (
    [ID]           INT            NULL,
    [NotifyChoice] NVARCHAR (255) NOT NULL
);

