﻿CREATE TABLE [dbo].[PartnerPackageIncludedItem]
(
	[PartnerPackageIncludedItemId] INT NOT NULL PRIMARY KEY IDENTITY,
	PartnerCoursePackageId INT,
	PackageIncludedItemId INT,
	Offered BIT,
	[CreatedDate] DATETIME NULL, 
	[CreatedBy] NVARCHAR(50) NULL, 
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(50) NULL, 
	CONSTRAINT [FK_PartnerPackageIncludedItem_PartnerCoursePackage_PartnerCoursePackageId] FOREIGN KEY (PartnerCoursePackageId) REFERENCES PartnerCoursePackage (PartnerCoursePackageId),
	CONSTRAINT [FK_PartnerPackageIncludedItem_PackageIncludedItem_PackageIncludedItemId] FOREIGN KEY (PackageIncludedItemId) REFERENCES PackageIncludedItem (PackageIncludedItemId)
)
