﻿CREATE TABLE [dbo].[PartnerPackageAdditionalItem]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY,
	PartnerCoursePackageId INT,
	UK NVARCHAR(255),
	DK  NVARCHAR(255),
	Price   DECIMAL(18,2),
	[CreatedDate] DATETIME NULL, 
	[CreatedBy] NVARCHAR(50) NULL, 
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(50) NULL, 
	CONSTRAINT [FK_PartnerPackageIncludedItem_PartnerPackageAdditionalItem_PartnerCoursePackageId] FOREIGN KEY (PartnerCoursePackageId) REFERENCES PartnerCoursePackage (PartnerCoursePackageId),
)
