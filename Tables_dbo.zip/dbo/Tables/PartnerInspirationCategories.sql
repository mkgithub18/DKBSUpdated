﻿CREATE TABLE [dbo].[PartnerInspirationCategories] (
    [PartnerInspirationCategoriesId]   INT           NOT NULL,
    [CRMPartnerId]                        INT           NOT NULL,
    [Heading]                          NVARCHAR (50) NULL,
    [Description]                      NVARCHAR (50) NULL,
    [Price]                            DECIMAL(18, 2)           NULL,
    [ApprovalStatus]                   BIT           NULL,
    [PartnerInspirationCategoriesSpId] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([PartnerInspirationCategoriesId] ASC),
    CONSTRAINT [FK_PartnerInspirationCategories_CRMPartner] FOREIGN KEY ([CRMPartnerId]) REFERENCES [dbo].[CRMPartner] ([CRMPartnerId])
);




