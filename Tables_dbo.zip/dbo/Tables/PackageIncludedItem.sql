﻿CREATE TABLE [dbo].[PackageIncludedItem]
(
	[PackageIncludedItemId] INT NOT NULL PRIMARY KEY IDENTITY,
	CoursePackageId INT,
	UK NVARCHAR(255),
	DK  NVARCHAR(255),
	Included BIT,
	SortingOrder INT,
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL,
	CONSTRAINT [FK_PackageIncludedItem_CoursePackageId] FOREIGN KEY (CoursePackageId) REFERENCES CoursePackage(CoursePackageId)
)
