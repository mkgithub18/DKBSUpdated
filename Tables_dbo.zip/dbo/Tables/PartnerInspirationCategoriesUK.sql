﻿CREATE TABLE [dbo].[PartnerInspirationCategoriesUK] (
    [PartnerInspirationCategoriesUKId] INT            NOT NULL,
    [CRMPartnerId]                        INT            NOT NULL,
    [Heading]                          NVARCHAR (50)  NULL,
    [Description]                      NVARCHAR (50)  NULL,
    [Price]                            DECIMAL(18, 2)            NULL,
    [ApprovalStatus]                   BIT            NULL,
    [PartnerInspirationCategoriesSpId] NVARCHAR (50)  NULL,
    [CreatedDate]                      DATETIME       NULL,
    [CreatedBy]                        NVARCHAR (255) NULL,
    [LastModified]                     DATETIME       NULL,
    [LastModifiedBY]                   NVARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([PartnerInspirationCategoriesUKId] ASC),
    CONSTRAINT [FK_PartnerInspirationCategoriesUK_CRMPartner] FOREIGN KEY ([CRMPartnerId]) REFERENCES [dbo].[CRMPartner] ([CRMPartnerId])
);



