﻿CREATE TABLE [dbo].[CenterInfoApproveStatus] (
    [ID]           INT            NULL,
    [NotifyChoice] NVARCHAR (255) NOT NULL
);

