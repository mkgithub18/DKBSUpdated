﻿CREATE TABLE [dbo].[Picture]
(
	[PictureId] INT NOT NULL PRIMARY KEY IDENTITY,
	[PictureName] NVARCHAR(255),
	[Title] NVARCHAR(255) NULL,
	[Description] NVARCHAR(500) NULL,
	[Position] INT NULL,
	[PictureFolderId] INT,
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL
	CONSTRAINT [FK_Picture_PictureFolderId] FOREIGN KEY (PictureFolderId) REFERENCES PictureFolder(PictureFolderId),

)
