﻿CREATE TABLE [dbo].[PartnerInspirationCategoriesDK] (
    [PartnerInspirationCategoriesDKId]   INT             NOT NULL,
    [CRMPartnerId]                       INT             NOT NULL,
    [Heading]                            NVARCHAR (50)   NULL,
    [Description]                        NVARCHAR (50)   NULL,
    [Price]                              DECIMAL (18, 2) NULL,
    [ApprovalStatus]                     BIT             NULL,
    [PartnerInspirationCategoriesDKSpId] NVARCHAR (50)   NULL,
    [Sorting]                            INT             NULL,
    [ApprovalStatusId]                   INT             NULL,
    [CreatedDate]                        DATETIME        NULL,
    [CreatedBy]                          NVARCHAR (255)  NULL,
    [LastModified]                       DATETIME        NULL,
    [LastModifiedBY]                     NVARCHAR (255)  NULL,
    PRIMARY KEY CLUSTERED ([PartnerInspirationCategoriesDKId] ASC),
    CONSTRAINT [FK_PartnerInspirationCategoriesDK_ContentStatus] FOREIGN KEY ([ApprovalStatusId]) REFERENCES [dbo].[ContentStatus] ([ContentStatusId]),
    CONSTRAINT [FK_PartnerInspirationCategoriesDK_CRMPartner] FOREIGN KEY ([CRMPartnerId]) REFERENCES [dbo].[CRMPartner] ([CRMPartnerId])
);