﻿CREATE TABLE [dbo].[ContentStatus]
(
	[ContentStatusId] INT NOT NULL PRIMARY KEY IDENTITY,
	[Description] NVARCHAR(255),
	[CreatedDate] DATETIME NULL, 
    [CreatedBy] NVARCHAR(50) NULL, 
    [LastModified] DATETIME NULL, 
    [LastModifiedBy] NVARCHAR(50) NULL, 
)
