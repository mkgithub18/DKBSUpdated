﻿CREATE TABLE [dbo].[DocumentCategory]
(
	[DocumentCategoryId] INT NOT NULL PRIMARY KEY IDENTITY,
	[CategoryName] NVARCHAR(255),
	[CreatedDate] DATETIME ,
	[CreatedBy] nvarchar(100),
	[LastModified] DATETIME NULL, 
	[LastModifiedBy] NVARCHAR(100) NULL
)
