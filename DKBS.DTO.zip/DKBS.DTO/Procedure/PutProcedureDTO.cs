﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Procedure
{
    public class PutProcedureDTO
    {
        public string ProcedureTitle { get; set; }
        public int? CauseOfRemovalId { get; set; }
        public int? ProcedureReviewTypeId { get; set; }
        public int? PartnerEmployeeId { get; set; } // TODO : Wether it has to allow null?
        public int? CustomerId { get; set; }
        public int? SRCommunicationId { get; set; } // ChatCommunincationId
        public int? ContactId { get; set; }
        public int? ProcedureCancelReasonId { get; set; }
        public int? ProcedureReplyId { get; set; }
        public int? UsedInEmailOffer { get; set; }
        public int? TurnOffNotification { get; set; }
        public int? ProcedureSharePointId { get; set; }
        public string IndustryCode { get; set; }
        public int? ProcedureStatusId { get; set; }
        public decimal? TotalPrice { get; set; }
        public decimal? SystemPrice { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

    }
}
