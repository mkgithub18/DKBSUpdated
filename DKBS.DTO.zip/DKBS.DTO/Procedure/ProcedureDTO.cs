﻿using DKBS.Domain;
using System;

namespace DKBS.DTO
{
    public class ProcedureDTO
    {
        public int ProcedureId { get; set; }
        public int BookingId { get; set; }
        public int CrmPartnerId { get; set; }
        public string ProcedureTitle { get; set; }
        public int? CauseOfRemovalId { get; set; }
        public int? PartnerEmployeeId { get; set; } // TODO : Wether it has to allow null?
        public int? CustomerId { get; set; }
        public int? SRCommunicationId { get; set; } // ChatCommunincationId
        public int? ContactId { get; set; }
        public int? UsedInEmailOffer { get; set; }
        public int? TurnOffNotification { get; set; }
        public int? ProcedureSharePointId { get; set; }
        public string IndustryCode { get; set; }
        public decimal? TotalPrice { get; set; }
        public decimal? SystemPrice { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public ProcedureStatus ProcedureStatus { get; set; }
        public ProcedureReviewType ProcedureReviewType { get; set; }
        public ProcedureCancelReason ProcedureCancelReason { get; set; }
        public ProcedureReply ProcedureReply { get; set; }
    }
}