﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Search
{
    public class SearchPartnerDTO
    {
        public int TotalRooms { get; set; }
        public int GroupRooms { get; set; }
        public int MaxSpaceAtRowOfChairs { get; set; }
        public int MaxspaceAtTables { get; set; }
        public bool StateAgreement { get; set; }
        public string PartnerType { get; set; }
        public string Regions { get; set; }
        public bool Offered { get; set; }
        public IEnumerable<int> RefreshmentList { get; set; }
    }
}
