﻿using DKBS.DTO.CoursePackage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Search
{
    public class SearchPartnerResultDTO
    {
        // partner 
        public CRMPartnerDTO CRMPartnerDTO { get; set; }
        
        // partner employee
        public IEnumerable<PartnerEmployeeDTO> PartnerEmployeeDTOs { get; set; }

        //partner course package details
        public IEnumerable<PartnerCoursePackageDTO> PartnerCoursePackageDtos { get; set; }
    }
}
