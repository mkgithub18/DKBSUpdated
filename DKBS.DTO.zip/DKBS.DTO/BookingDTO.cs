﻿using System;
using System.Collections.Generic;

namespace DKBS.DTO
{
    public class BookingDTO
    {
        public BookingDTO()
        {
            BookingRegionDTOs = new List<BookingRegionDTO>();
            BookingRoomDTOs = new List<BookingRoomDTO>();
            BookingArrangementTypeDTOs = new List<BookingArrangementTypeDTO>();
            BookingAlternativeServiceDTOs = new List<BookingAlternativeServiceDTO>();
            ProcedureDTOs = new List<ProcedureDTO>();
        }
        public int BookingId { get; set; }
        //public PartnerDTO PartnerDTO { get; set; }
        public CRMPartnerDTO CRMPartnerDTO { get; set; }
        public CustomerDTO CustomerDTO { get; set; }
        public TableTypeDTO TableTypeDTO { get; set; }
        public CancellationReasonDTO CancellationReasonDTO { get; set; }
        public CauseOfRemovalDTO CauseOfRemovalDTO { get; set; }
        public ContactPersonDTO ContactPersonDTO { get; set; }
        public BookingAndStatusDTO BookingAndStatusDTO { get; set; }
        public FlowDTO FlowDTO { get; set; }
        public MailLanguageDTO MailLanguageDTO { get; set; }
        //public PartnerTypeDTO PartnerTypeDTO { get; set; }
        public ParticipantTypeDTO ParticipantTypeDTO { get; set; }
        public PurposeDTO PurposeDTO { get; set; }
        public LeadOfOriginDTO LeadOfOriginDTO { get; set; }
        public CampaignDTO CampaignDTO { get; set; }
        public DateTime? ArrivalDateTime { get; set; }
        public DateTime? DepartDateTime { get; set; }
        public bool? FlexibleDates { get; set; }
        public string InternalHistory { get; set; }
        public List<BookingRegionDTO> BookingRegionDTOs { get; set; }
        public List<BookingRoomDTO> BookingRoomDTOs { get; set; }
        public List<BookingArrangementTypeDTO> BookingArrangementTypeDTOs { get; set; }
        public List<BookingAlternativeServiceDTO> BookingAlternativeServiceDTOs { get; set; }
        public List<ProcedureDTO> ProcedureDTOs { get; set; }
    }
}