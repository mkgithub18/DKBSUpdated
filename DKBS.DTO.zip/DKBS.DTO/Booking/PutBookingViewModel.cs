﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Booking
{
    public class PutBookingViewModel : BookingViewModelBase
    {
        public PutBookingViewModel() : base()
        {

        }
        public int? BookingAndStatusId { get; set; }
        public int? FlowId { get; set; }
        public int? MailLanguageId { get; set; }

    }
}
