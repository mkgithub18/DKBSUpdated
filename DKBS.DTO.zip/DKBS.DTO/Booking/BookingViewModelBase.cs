﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Booking
{
    public class BookingViewModelBase
    {
        public BookingViewModelBase()
        {
            RegionIds = new List<int>();
            BookingRoomViewModel = new List<BookingRoomViewModel>();
            BookingArrangementTypeViewModel = new List<BookingArrangementTypeViewModel>();
            BookingAlternativeServiceViewModel = new List<BookingAlternativeServiceViewModel>();
            CrmPartnerIds = new List<int>();
        }

        public int? CRMPartnerId { get; set; }
        public int? CustomerId { get; set; }
        public int? ContactPersonId { get; set; }
        public int? PartnerEmployeeId { get; set; }
        public int? PartnerTypeId { get; set; }
        public int? CampaignId { get; set; }
        public int? LeadOfOriginId { get; set; }
        public int? ParticipantTypeId { get; set; }
        public int? PurposeId { get; set; }
        public int? TableTypeId { get; set; }
        public int? CauseOfRemovalId { get; set; }
        public int? CancellationReasonId { get; set; }
        public int? RegionId { get; set; }
        public int? CenterMatchingId { get; set; }
        public int? RefreshmentId { get; set; }
        public DateTime? Arrival { get; set; }
        public DateTime? Departure { get; set; }
        public bool? FlexibleDates { get; set; }
        public bool? Notification { get; set; }
        public string BookingName { get; set; }
        public string SuplimentaryWishes { get; set; }
        public string BookingResponsible { get; set; }
        public string InternalHistory { get; set; }
        public string MeetingSeries { get; set; }
        public string AdditionalSeriesText { get; set; }
        public string IsMainSeriesCase { get; set; }
        public string DkbsNotes { get; set; }
        public string NumberOfParticipants { get; set; }
        public string NumberOfSingleRooms { get; set; }
        public string CentersCommentsDkbs { get; set; }
        public string BookkeepersCommentsDkbs { get; set; }
        public string DifferenceInDaysDkbs { get; set; }
        public string CommissionRateDkbs { get; set; }
        public string CommissionForEvent { get; set; }
        public string ReferralRate { get; set; }
        public string ReferralForArrangement { get; set; }
        public string ProvisionLink { get; set; }
        public string ReferralProvisionLink { get; set; }
        public string LinkToProvisionItem { get; set; }
        public string EvaluationDate { get; set; }
        public string CustomerFromReference { get; set; }
        public string ContactFromReference { get; set; }
        public string EmailFromReference { get; set; }
        public string PhoneFromReference { get; set; }
        public string CityFromReference { get; set; }
        public string PostNumberFromReference { get; set; }
        public string CountryFromReference { get; set; }
        public string NumberOfDoubleRooms { get; set; }
        public List<int> RegionIds { get; set; }
        public List<BookingRoomViewModel> BookingRoomViewModel { get; set; }
        public List<BookingArrangementTypeViewModel> BookingArrangementTypeViewModel { get; set; }
        public List<BookingAlternativeServiceViewModel> BookingAlternativeServiceViewModel { get; set; }
        public List<int> CrmPartnerIds { get; set; }

    }

}
