﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.Booking
{
    public class PostBookingViewModel : BookingViewModelBase
    {
        // =========== Set below with default values ===============
        //public int? BookingAndStatusId { get; set; } = new 
        //public int? FlowId { get; set; }
        //public int? MailLanguageId { get; set; }
        // ==========================================================

    }
}
