﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class CoursePackageDTO
    {
        public CoursePackageDTO()
        {
            PackageIncludedItemDTOs = new List<PackageIncludedItemDTO>();
        }
        public int CoursePackageId { get; set; }
        public string CoursePackageName { get; set; }
        public string CoursePackageNameEN { get; set; }
        public bool? Offered { get; set; }
        public decimal Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public List<PackageIncludedItemDTO> PackageIncludedItemDTOs { get; set; }
    }
}
