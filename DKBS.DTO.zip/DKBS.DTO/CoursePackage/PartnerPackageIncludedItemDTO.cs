﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class PartnerPackageIncludedItemDTO
    {
        public int PartnerPackageIncludedItemId { get; set; }
        public int PartnerCoursePackageId { get; set; }
        //public int PackageIncludedItemId { get; set; }
        public bool Offered { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        //public PartnerCoursePackageDTO PartnerCoursePackageDTO { get; set; }

        //TODO : if it is required enable else no need beacuse can already get data
        //public PackageIncludedItemDTO  PackageIncludedItemDTO { get; set; }

    }
}
