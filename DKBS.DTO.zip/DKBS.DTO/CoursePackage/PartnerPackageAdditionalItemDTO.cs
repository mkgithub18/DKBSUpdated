﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class PartnerPackageAdditionalItemDTO
    {
        public int Id { get; set; }

        //public int PartnerPackageAdditionalItemId { get; set; }
        public int PartnerCoursePackageId { get; set; }
        public string UK { get; set; }
        public string DK { get; set; }
        public decimal Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        //public PartnerCoursePackageDTO PartnerCoursePackageDTO { get; set; }
        #endregion

    }
}
