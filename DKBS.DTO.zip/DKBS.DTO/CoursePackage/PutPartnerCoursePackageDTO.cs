﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class PutPartnerCoursePackageDTO
    {
        //public int CrmPartnerId { get; set; } while updating we are not providing to update associated partner entry
        public PutPartnerCoursePackageDTO()
        {
            PartnerPackageIncludedItemDTOs = new List<PutPartnerPackageIncludedItemDTO>();
            PartnerPackageAdditionalItemDTOs = new List<PutPartnerPackageAdditionalItemDTO>();
            PartnerPackageYearDTOs = new List<PutPartnerPackageYearDTO>();
        }

        public int CoursePackageId { get; set; }
        public int ContentStatusId { get; set; }
        public bool Offered { get; set; }
        public decimal Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public List<PutPartnerPackageIncludedItemDTO> PartnerPackageIncludedItemDTOs { get; set; }
        public List<PutPartnerPackageAdditionalItemDTO> PartnerPackageAdditionalItemDTOs { get; set; }
        public List<PutPartnerPackageYearDTO> PartnerPackageYearDTOs { get; set; }
    }
}
