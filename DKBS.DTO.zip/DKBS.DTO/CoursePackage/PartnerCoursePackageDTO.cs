﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class PartnerCoursePackageDTO
    {
        public PartnerCoursePackageDTO()
        {
            PartnerPackageIncludedItemDTOs = new List<PartnerPackageIncludedItemDTO>();
            PartnerPackageAdditionalItemDTOs = new List<PartnerPackageAdditionalItemDTO>();
            PartnerPackageYearDTOs = new List<PartnerPackageYearDTO>();
        }
        public int PartnerCoursePackageId { get; set; }

        // Enable below if only id has to be sent and disable corrosponding DTO below e.g CRMPartnerDTO and CoursePackageDTO
        //public int CrmPartnerId { get; set; }
        //public int CoursePackageId { get; set; }
        public bool Offered { get; set; }
        public decimal Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public CRMPartnerDTO CRMPartnerDTO { get; set; }
        public CoursePackageDTO CoursePackageDTO { get; set; }
        public List<PartnerPackageIncludedItemDTO> PartnerPackageIncludedItemDTOs { get; set; }
        public List<PartnerPackageAdditionalItemDTO> PartnerPackageAdditionalItemDTOs { get; set; }
        public List<PartnerPackageYearDTO> PartnerPackageYearDTOs { get; set; }
    }
}
