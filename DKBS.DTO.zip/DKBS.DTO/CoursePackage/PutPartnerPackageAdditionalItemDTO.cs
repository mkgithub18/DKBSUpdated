﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.DTO.CoursePackage
{
    public class PutPartnerPackageAdditionalItemDTO
    {
        public string UK { get; set; }
        public string DK { get; set; }
        public decimal Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
