﻿namespace DKBS.DTO
{
    public class BookingRegionDTO
    {
        public int BookingRegionId { get; set; }
        public int BookingId { get; set; }
        public RegionDTO RegionDTO { get; set; }
    }
}