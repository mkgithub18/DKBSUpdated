﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain
{
    public class InternalHistory
    {
        public int? ID { get; set; }
        public int? BookingID { get; set; }
        public string InternalHistroy { get; set; }
    }

}
