﻿using System;
using DKBS.Domain.CoursePackage;

namespace DKBS.Domain
{
    public class BookingArrangementType
    {
        public int BookingArrangementTypeId { get; set; }
        public int BookingId { get; set; }
        public Booking Booking { get; set; }
        public DKBS.Domain.CoursePackage.CoursePackage CoursePackage { get; set; }

        //public ServiceCatalog ServiceCatalog  { get; set; }
        //ServiceCatalogId changed to CoursePackage
        public int CoursePackageId { get; set; }
        public int NumberOfParticipants { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? FromDate { get; set; }

    }
}