﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DKBS.Domain
{
    public class Procedure
    {
        public int ProcedureId { get; set; }
        public string ProcedureTitle { get; set; }
        public int BookingId { get; set; }
        public int CrmPartnerId { get; set; }
        public int? CauseOfRemovalId { get; set; }
        public int? ProcedureReviewTypeId { get; set; }
        public int? PartnerEmployeeId { get; set; } // TODO : Wether it has to allow null?
        public int? CustomerId { get; set; }
        public int? SRCommunicationId { get; set; } // ChatCommunincationId
        public int? ContactId { get; set; }
        public int? ProcedureCancelReasonId { get; set; }
        public int? ProcedureReplyId { get; set; }
        public int? UsedInEmailOffer { get; set; }
        public int? TurnOffNotification { get; set; }
        public int? ProcedureSharePointId { get; set; }
        public string IndustryCode { get; set; }
        public int? ProcedureStatusId { get; set; }
        public decimal? TotalPrice { get; set; }
        public decimal? SystemPrice { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        public ProcedureStatus ProcedureStatus { get; set; }
        public ProcedureReviewType  ProcedureReviewType { get; set; }
        public ProcedureCancelReason ProcedureCancelReason { get; set; }
        public ProcedureReply ProcedureReply { get; set; }
        #endregion

    }
}