﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class PartnerCoursePackage
    {
        public PartnerCoursePackage()
        {
            PartnerPackageIncludedItems = new List<PartnerPackageIncludedItem>();
            PartnerPackageAdditionalItems = new List<PartnerPackageAdditionalItem>();
            PartnerPackageYears = new List<PartnerPackageYear>();
        }
        public int PartnerCoursePackageId { get; set; }
        public int CrmPartnerId { get; set; }
        public int CoursePackageId { get; set; }
        public int ContentStatusId { get; set; }
        public bool? Offered { get; set; } = false;
        public decimal? Price { get; set; } = 0;
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        public CRMPartner CRMPartner { get; set; }
        public CoursePackage CoursePackage { get; set; }
        public List<PartnerPackageIncludedItem> PartnerPackageIncludedItems { get; set; }
        public List<PartnerPackageAdditionalItem> PartnerPackageAdditionalItems { get; set; }
        public List<PartnerPackageYear> PartnerPackageYears { get; set; }

        #endregion
    }
}
