﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class PartnerPackageIncludedItem
    {
        public int PartnerPackageIncludedItemId { get; set; }
        public int PartnerCoursePackageId { get; set; }
        //public int PackageIncludedItemId { get; set; } We don't need this
        public bool? Offered { get; set; } = false;
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }


        #region Navigation Properties
        //public PartnerCoursePackage PartnerCoursePackage { get; set; }
        //public PackageIncludedItem PackageIncludedItem { get; set; }
        #endregion

    }
}
