﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class PartnerPackageAdditionalItem
    {
        [Key]
        public int Id { get; set; } // TODO: chanage ID to PartnerPackageAdditionalItemId later
        //PartnerPackageAdditionalItemId
        //public int PartnerPackageAdditionalItemId { get; set; }
        public int PartnerCoursePackageId { get; set; }
        public string UK { get; set; }
        public string DK { get; set; }
        public decimal Price { get; set; } = 0;
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        //public PartnerCoursePackage PartnerCoursePackage { get; set; }
        #endregion
    }
}
