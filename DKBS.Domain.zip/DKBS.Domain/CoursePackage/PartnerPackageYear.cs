﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class PartnerPackageYear
    {
        [Key]
        public int Id { get; set; }
        //PartnerPackageYearId
        //public int PartnerPackageYearId { get; set; }
        public int PartnerCoursePackageId { get; set; }
        public int Year { get; set; }
        public decimal? PricePerPerson { get; set; } = 0;
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        //public PartnerCoursePackage PartnerCoursePackage { get; set; }
        #endregion
    }
}
