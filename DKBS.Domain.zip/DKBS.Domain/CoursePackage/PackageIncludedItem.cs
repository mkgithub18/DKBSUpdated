﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class PackageIncludedItem
    {
        public int PackageIncludedItemId { get; set; }
        public int CoursePackageId { get; set; }
        public string UK { get; set; }
        public string DK { get; set; }
        public bool? Included { get; set; }
        public int? SortingOrder { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Navigation Properties
        
        #endregion
    }
}
