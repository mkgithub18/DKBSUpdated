﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKBS.Domain.CoursePackage
{
    public class CoursePackage
    {
        public CoursePackage()
        {
            PackageIncludedItems = new List<PackageIncludedItem>();
        }
        public int CoursePackageId { get; set; }
        public string CoursePackageName { get; set; }
        public string CoursePackageNameEN { get; set; }
        public bool? Offered { get; set; }
        public decimal? Price { get; set; }
        public DateTime? LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        #region Nvaigation Properties
        public List<PackageIncludedItem> PackageIncludedItems { get; set; }
        #endregion
    }
}
