﻿using System;
using System.Collections.Generic;

namespace DKBS.Domain
{
    public class Booking
    {
        public Booking()
        {
            BookingRegions = new List<BookingRegion>();
            BookingRoom = new List<BookingRoom>();
            BookingArrangementType = new List<BookingArrangementType>();
            BookingAlternativeService = new List<BookingAlternativeService>();
            Procedures = new List<Procedure>();
        }
        public int BookingId { get; set; }
        public int? CRMPartnerId { get; set; }
        public int? BookingSharepointId { get; set; }
        public int? CustomerId { get; set; }
        public int? ContactPersonId { get; set; }
        public int? PartnerEmployeeId { get; set; }
        public int? BookingAndStatusId { get; set; }
        public int? FlowId { get; set; }
        public int? MailLanguageId { get; set; }
        public int? PartnerTypeId { get; set; }
        public int? CampaignId { get; set; }
        public int? LeadOfOriginId { get; set; }
        public int? ParticipantTypeId { get; set; }
        public int? PurposeId { get; set; }
        public int? TableTypeId { get; set; }
        public int? CauseOfRemovalId { get; set; }
        public int? CancellationReasonId { get; set; }

        //public int? RegionId { get; set; } It is a collection       
        public int? CenterMatchingId { get; set; }
        public int? RefreshmentId { get; set; }
        public DateTime? Arrival { get; set; }
        public DateTime? Departure { get; set; }
        public bool? FlexibleDates { get; set; }
        public bool? Notification { get; set; }
        public string BookingName { get; set; }
        public string SuplimentaryWishes { get; set; }
        public string BookingResponsible { get; set; }
        public string InternalHistory { get; set; }
        public string MeetingSeries { get; set; }
        public string AdditionalSeriesText { get; set; }
        public string IsMainSeriesCase { get; set; }
        public string DkbsNotes { get; set; }
        public string NumberOfParticipants { get; set; }
        public string NumberOfSingleRooms { get; set; }
        public string CentersCommentsDkbs { get; set; }
        public string BookkeepersCommentsDkbs { get; set; }
        public string DifferenceInDaysDkbs { get; set; }
        public string CommissionRateDkbs { get; set; }
        public string CommissionForEvent { get; set; }
        public string ReferralRate { get; set; }
        public string ReferralForArrangement { get; set; }
        public string ProvisionLink { get; set; }
        public string ReferralProvisionLink { get; set; }
        public string LinkToProvisionItem { get; set; }
        public string EvaluationDate { get; set; }
        public string CustomerFromReference { get; set; }
        public string ContactFromReference { get; set; }
        public string EmailFromReference { get; set; }
        public string PhoneFromReference { get; set; }
        public string CityFromReference { get; set; }
        public string PostNumberFromReference { get; set; }
        public string CountryFromReference { get; set; }
        public string NumberOfDoubleRooms { get; set; }

        #region Navigation Properties
        public CRMPartner CRMPartner { get; set; }
        public Customer Customer { get; set; }
        public ContactPerson ContactPerson { get; set; }
        public PartnerEmployee PartnerEmployee { get; set; }
        public BookingAndStatus BookingAndStatus { get; set; }
        public Flow Flow { get; set; }
        public MailLanguage MailLanguage { get; set; }
        public PartnerType  PartnerType { get; set; }
        public Campaign  Campaign { get; set; }
        public LeadOfOrigin LeadOfOrigin { get; set; }
        public ParticipantType  ParticipantType { get; set; }
        public Purpose Purpose { get; set; }
        public TableType TableType { get; set; }
        public CauseOfRemoval CauseOfRemoval { get; set; }
        public CancellationReason CancellationReason { get; set; }
        public List<BookingRegion> BookingRegions { get; set; }
        public CenterMatching  CenterMatching { get; set; }
        public List<Refreshment>  Refreshment { get; set; }
        public List<BookingRoom> BookingRoom { get; set; }
        public List<BookingArrangementType> BookingArrangementType { get; set; }
        public List<BookingAlternativeService> BookingAlternativeService { get; set; }
        public List<Procedure> Procedures { get; set; }

        #endregion
    }
}