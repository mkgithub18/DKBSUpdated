﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DKBS.Domain
{
    public class PartnerCenterInfo
    {
        public int PartnerCenterInfoId { get; set; }
        public int CrmPartnerId { get; set; }
        public int? TotalRooms { get; set; } = 0;
        public int? GroupRooms { get; set; } = 0;
        public int? MaxSpaceAtRowOfChairs { get; set; } = 0;
        public int? MaxspaceAtTables { get; set; } = 0;
        public bool? StateAgreement { get; set; } = false;
        public string MaxAccommodation { get; set; }
        public string PartnerCenfoInfoSPId { get; set; }
        public int? NumberOfSingleRooms { get; set; } = 0;
        public int? NumberOfDoubleRooms { get; set; } = 0;
        public int? Suite { get; set; } = 0;
        public int? DistanceToAddtiionalAccommodation { get; set; } = 0;
        public int? Chamber { get; set; } = 0;
        public int? HandicapRooms { get; set; } = 0;
        public int? MaximumNumberOfVisitors { get; set; } = 0;
        public int? MaxDiningPlacesInRestaurant { get; set; } = 0;
        public int? MaxDiningPlacesInRoom { get; set; } = 0;
        public int? MaxSpaceInAuditorium { get; set; } = 0;
        public int? MinParticipants { get; set; } = 0;
        public int? AirportDistance { get; set; } = 0;
        public int? StationDdistance { get; set; } = 0;
        public int? DistanceToBus { get; set; } = 0;
        public int? DistanceToMotorway { get; set; } = 0;
        public int? NumberOfFreeParkingSpaces { get; set; } = 0;
        public int? DistanceToFreeParking { get; set; } = 0;
        public int? NumberOfParkingSpaces { get; set; } = 0;
        public int? DistanceToPayParking { get; set; } = 0;
        public bool? EnvironmentalCertificate { get; set; } = false;
        public bool? AgreementForEmployees { get; set; } = false;
        public bool? Handicapfriendly { get; set; } = false;
        public bool? RegionsAgreement { get; set; } = false;
        public bool? Bar { get; set; } = false;
        public bool? Lounge { get; set; } = false;
        public bool? BilliardsDartTableTennis { get; set; } = false;
        public bool? Spa { get; set; } = false;
        public bool? Pool { get; set; } = false;
        public bool? FitnessRoom { get; set; } = false;
        public bool? Casino { get; set; } = false;
        public int? DiningArea { get; set; } = 0;
        public bool? GreenArea { get; set; } = false;
        public bool? Golf { get; set; } = false;
        public bool? AirCondition { get; set; } = false;
        public bool? CookingSchool { get; set; } = false;
        public int? NoOfRooms { get; set; } = 0;
        public int? Auditoriums { get; set; } = 0;
        //public bool? ApprovalStatus { get; set; } // TODO: Removed it as it doesn't fit here check once
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBY { get; set; }
        public int? ApprovalStatusId { get; set; } = 0;
        public string PartnerCentInfoSpId { get; set; }
    }
}
